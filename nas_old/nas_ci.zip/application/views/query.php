<!-------------------------------------start-------------------------------------------------->  

<div class="input-append dataInput">
    <input class="span2" id="appendedDropdownButton" placeholder ="請輸入關鍵字" se ="1" type="text">
    <div class="btn-group">
        <button class="btn dropdown-toggle" data-toggle="dropdown"><span class="caret"></span></button>
        <ul class="dropdown-menu" id ="selects">
            <li><a href="#" se ="1">關鍵字</a></li>
            <li><a href="#" se ="2">指導教授</a></li>
            <li><a href="#" se ="3">專題名稱</a></li>
        </ul>
    </div>
    <button type="submit" class="btn" >開始搜尋</button>
</div>
<div class ="well span11" style ="margin-top: 10px">
    <table id ="result" class="table">
     <th>專題名稱</th><th>指導教授</th><th>專題分類</th><th>專題敘述</th><th>組長名稱</th><th>組長學號</th><th>上傳日期</th>
     
    </table>    
</div>    
<!-------------------------------------end-------------------------------------------------->  