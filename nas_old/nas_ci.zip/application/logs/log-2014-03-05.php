<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-03-05 00:44:40 --> Config Class Initialized
DEBUG - 2014-03-05 00:44:40 --> Hooks Class Initialized
DEBUG - 2014-03-05 00:44:40 --> Utf8 Class Initialized
DEBUG - 2014-03-05 00:44:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 00:44:40 --> URI Class Initialized
DEBUG - 2014-03-05 00:44:40 --> Router Class Initialized
DEBUG - 2014-03-05 00:44:40 --> Output Class Initialized
DEBUG - 2014-03-05 00:44:40 --> Security Class Initialized
DEBUG - 2014-03-05 00:44:40 --> Input Class Initialized
DEBUG - 2014-03-05 00:44:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 00:44:40 --> Language Class Initialized
DEBUG - 2014-03-05 00:44:40 --> Loader Class Initialized
DEBUG - 2014-03-05 00:44:40 --> Database Driver Class Initialized
ERROR - 2014-03-05 00:44:40 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\www\nas\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-03-05 00:44:41 --> Session Class Initialized
DEBUG - 2014-03-05 00:44:41 --> Helper loaded: string_helper
DEBUG - 2014-03-05 00:44:41 --> A session cookie was not found.
DEBUG - 2014-03-05 00:44:41 --> Session routines successfully run
DEBUG - 2014-03-05 00:44:41 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 00:44:41 --> User Agent Class Initialized
DEBUG - 2014-03-05 00:44:41 --> Controller Class Initialized
DEBUG - 2014-03-05 00:44:41 --> Helper loaded: url_helper
DEBUG - 2014-03-05 00:44:41 --> this->setMessage()
ERROR - 2014-03-05 00:44:42 --> 404 Page Not Found --> welcome/register
DEBUG - 2014-03-05 00:51:51 --> Config Class Initialized
DEBUG - 2014-03-05 00:51:52 --> Hooks Class Initialized
DEBUG - 2014-03-05 00:51:52 --> Utf8 Class Initialized
DEBUG - 2014-03-05 00:51:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 00:51:52 --> URI Class Initialized
DEBUG - 2014-03-05 00:51:52 --> Router Class Initialized
DEBUG - 2014-03-05 00:51:52 --> Output Class Initialized
DEBUG - 2014-03-05 00:51:52 --> Security Class Initialized
DEBUG - 2014-03-05 00:51:52 --> Input Class Initialized
DEBUG - 2014-03-05 00:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 00:51:52 --> Language Class Initialized
DEBUG - 2014-03-05 00:51:52 --> Loader Class Initialized
DEBUG - 2014-03-05 00:51:52 --> Database Driver Class Initialized
DEBUG - 2014-03-05 00:51:52 --> Session Class Initialized
DEBUG - 2014-03-05 00:51:52 --> Helper loaded: string_helper
DEBUG - 2014-03-05 00:51:52 --> Session routines successfully run
DEBUG - 2014-03-05 00:51:52 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 00:51:52 --> User Agent Class Initialized
DEBUG - 2014-03-05 00:51:52 --> Controller Class Initialized
DEBUG - 2014-03-05 00:51:52 --> Helper loaded: url_helper
DEBUG - 2014-03-05 00:51:52 --> this->setMessage()
DEBUG - 2014-03-05 00:51:52 --> File loaded: application/views/register.php
DEBUG - 2014-03-05 00:51:52 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 00:51:53 --> Final output sent to browser
DEBUG - 2014-03-05 00:51:53 --> Total execution time: 1.2190
DEBUG - 2014-03-05 00:55:19 --> Config Class Initialized
DEBUG - 2014-03-05 00:55:19 --> Hooks Class Initialized
DEBUG - 2014-03-05 00:55:19 --> Utf8 Class Initialized
DEBUG - 2014-03-05 00:55:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 00:55:20 --> URI Class Initialized
DEBUG - 2014-03-05 00:55:20 --> Router Class Initialized
DEBUG - 2014-03-05 00:55:20 --> Output Class Initialized
DEBUG - 2014-03-05 00:55:20 --> Security Class Initialized
DEBUG - 2014-03-05 00:55:20 --> Input Class Initialized
DEBUG - 2014-03-05 00:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 00:55:20 --> Language Class Initialized
DEBUG - 2014-03-05 00:55:20 --> Loader Class Initialized
DEBUG - 2014-03-05 00:55:20 --> Database Driver Class Initialized
ERROR - 2014-03-05 00:55:21 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\www\nas\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-03-05 00:55:22 --> Session Class Initialized
DEBUG - 2014-03-05 00:55:22 --> Helper loaded: string_helper
DEBUG - 2014-03-05 00:55:22 --> Session routines successfully run
DEBUG - 2014-03-05 00:55:22 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 00:55:22 --> User Agent Class Initialized
DEBUG - 2014-03-05 00:55:22 --> Controller Class Initialized
DEBUG - 2014-03-05 00:55:23 --> Helper loaded: url_helper
DEBUG - 2014-03-05 00:55:23 --> this->setMessage()
DEBUG - 2014-03-05 00:55:23 --> File loaded: application/views/register.php
DEBUG - 2014-03-05 00:55:23 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 00:55:23 --> Final output sent to browser
DEBUG - 2014-03-05 00:55:23 --> Total execution time: 3.8267
DEBUG - 2014-03-05 00:55:24 --> Config Class Initialized
DEBUG - 2014-03-05 00:55:24 --> Hooks Class Initialized
DEBUG - 2014-03-05 00:55:24 --> Utf8 Class Initialized
DEBUG - 2014-03-05 00:55:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 00:55:24 --> URI Class Initialized
DEBUG - 2014-03-05 00:55:24 --> Router Class Initialized
DEBUG - 2014-03-05 00:55:25 --> Output Class Initialized
DEBUG - 2014-03-05 00:55:25 --> Security Class Initialized
DEBUG - 2014-03-05 00:55:25 --> Input Class Initialized
DEBUG - 2014-03-05 00:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 00:55:25 --> Language Class Initialized
DEBUG - 2014-03-05 00:55:25 --> Loader Class Initialized
DEBUG - 2014-03-05 00:55:25 --> Database Driver Class Initialized
ERROR - 2014-03-05 00:55:25 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\www\nas\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-03-05 00:55:26 --> Session Class Initialized
DEBUG - 2014-03-05 00:55:26 --> Helper loaded: string_helper
DEBUG - 2014-03-05 00:55:26 --> Session routines successfully run
DEBUG - 2014-03-05 00:55:26 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 00:55:26 --> User Agent Class Initialized
DEBUG - 2014-03-05 00:55:27 --> Controller Class Initialized
DEBUG - 2014-03-05 00:55:27 --> Helper loaded: url_helper
DEBUG - 2014-03-05 00:55:27 --> this->setMessage()
ERROR - 2014-03-05 00:55:27 --> 404 Page Not Found --> welcome/Controls
DEBUG - 2014-03-05 00:55:36 --> Config Class Initialized
DEBUG - 2014-03-05 00:55:36 --> Hooks Class Initialized
DEBUG - 2014-03-05 00:55:36 --> Utf8 Class Initialized
DEBUG - 2014-03-05 00:55:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 00:55:36 --> URI Class Initialized
DEBUG - 2014-03-05 00:55:36 --> Router Class Initialized
DEBUG - 2014-03-05 00:55:36 --> Output Class Initialized
DEBUG - 2014-03-05 00:55:36 --> Security Class Initialized
DEBUG - 2014-03-05 00:55:36 --> Input Class Initialized
DEBUG - 2014-03-05 00:55:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 00:55:36 --> Language Class Initialized
DEBUG - 2014-03-05 00:55:36 --> Loader Class Initialized
DEBUG - 2014-03-05 00:55:36 --> Database Driver Class Initialized
DEBUG - 2014-03-05 00:55:37 --> Session Class Initialized
DEBUG - 2014-03-05 00:55:37 --> Helper loaded: string_helper
DEBUG - 2014-03-05 00:55:37 --> Session routines successfully run
DEBUG - 2014-03-05 00:55:37 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 00:55:37 --> User Agent Class Initialized
DEBUG - 2014-03-05 00:55:37 --> Controller Class Initialized
DEBUG - 2014-03-05 00:55:37 --> Helper loaded: url_helper
DEBUG - 2014-03-05 00:55:37 --> this->setMessage()
DEBUG - 2014-03-05 00:55:37 --> File loaded: application/views/register.php
DEBUG - 2014-03-05 00:55:37 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 00:55:37 --> Final output sent to browser
DEBUG - 2014-03-05 00:55:38 --> Total execution time: 1.8832
DEBUG - 2014-03-05 00:55:38 --> Config Class Initialized
DEBUG - 2014-03-05 00:55:38 --> Hooks Class Initialized
DEBUG - 2014-03-05 00:55:38 --> Utf8 Class Initialized
DEBUG - 2014-03-05 00:55:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 00:55:38 --> URI Class Initialized
DEBUG - 2014-03-05 00:55:38 --> Router Class Initialized
DEBUG - 2014-03-05 00:55:38 --> Output Class Initialized
DEBUG - 2014-03-05 00:55:38 --> Security Class Initialized
DEBUG - 2014-03-05 00:55:39 --> Input Class Initialized
DEBUG - 2014-03-05 00:55:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 00:55:39 --> Language Class Initialized
DEBUG - 2014-03-05 00:55:39 --> Loader Class Initialized
DEBUG - 2014-03-05 00:55:39 --> Database Driver Class Initialized
DEBUG - 2014-03-05 00:55:39 --> Session Class Initialized
DEBUG - 2014-03-05 00:55:39 --> Helper loaded: string_helper
DEBUG - 2014-03-05 00:55:39 --> Session routines successfully run
DEBUG - 2014-03-05 00:55:39 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 00:55:39 --> User Agent Class Initialized
DEBUG - 2014-03-05 00:55:39 --> Controller Class Initialized
DEBUG - 2014-03-05 00:55:39 --> Helper loaded: url_helper
DEBUG - 2014-03-05 00:55:40 --> this->setMessage()
ERROR - 2014-03-05 00:55:40 --> 404 Page Not Found --> welcome/Controls
DEBUG - 2014-03-05 00:55:43 --> Config Class Initialized
DEBUG - 2014-03-05 00:55:44 --> Hooks Class Initialized
DEBUG - 2014-03-05 00:55:44 --> Utf8 Class Initialized
DEBUG - 2014-03-05 00:55:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 00:55:44 --> URI Class Initialized
DEBUG - 2014-03-05 00:55:44 --> Router Class Initialized
DEBUG - 2014-03-05 00:55:44 --> Output Class Initialized
DEBUG - 2014-03-05 00:55:44 --> Security Class Initialized
DEBUG - 2014-03-05 00:55:44 --> Input Class Initialized
DEBUG - 2014-03-05 00:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 00:55:44 --> Language Class Initialized
DEBUG - 2014-03-05 00:55:44 --> Loader Class Initialized
DEBUG - 2014-03-05 00:55:44 --> Database Driver Class Initialized
DEBUG - 2014-03-05 00:55:45 --> Session Class Initialized
DEBUG - 2014-03-05 00:55:45 --> Helper loaded: string_helper
DEBUG - 2014-03-05 00:55:45 --> Session routines successfully run
DEBUG - 2014-03-05 00:55:45 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 00:55:45 --> User Agent Class Initialized
DEBUG - 2014-03-05 00:55:45 --> Controller Class Initialized
DEBUG - 2014-03-05 00:55:45 --> Helper loaded: url_helper
DEBUG - 2014-03-05 00:55:45 --> this->setMessage()
DEBUG - 2014-03-05 00:55:45 --> File loaded: application/views/query.php
DEBUG - 2014-03-05 00:55:45 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 00:55:46 --> Final output sent to browser
DEBUG - 2014-03-05 00:55:46 --> Total execution time: 2.0375
DEBUG - 2014-03-05 00:55:48 --> Config Class Initialized
DEBUG - 2014-03-05 00:55:48 --> Hooks Class Initialized
DEBUG - 2014-03-05 00:55:48 --> Utf8 Class Initialized
DEBUG - 2014-03-05 00:55:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 00:55:48 --> URI Class Initialized
DEBUG - 2014-03-05 00:55:48 --> Router Class Initialized
DEBUG - 2014-03-05 00:55:48 --> Output Class Initialized
DEBUG - 2014-03-05 00:55:48 --> Security Class Initialized
DEBUG - 2014-03-05 00:55:48 --> Input Class Initialized
DEBUG - 2014-03-05 00:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 00:55:48 --> Language Class Initialized
DEBUG - 2014-03-05 00:55:49 --> Loader Class Initialized
DEBUG - 2014-03-05 00:55:49 --> Database Driver Class Initialized
DEBUG - 2014-03-05 00:55:49 --> Session Class Initialized
DEBUG - 2014-03-05 00:55:49 --> Helper loaded: string_helper
DEBUG - 2014-03-05 00:55:49 --> Session routines successfully run
DEBUG - 2014-03-05 00:55:49 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 00:55:49 --> User Agent Class Initialized
DEBUG - 2014-03-05 00:55:49 --> Controller Class Initialized
DEBUG - 2014-03-05 00:55:49 --> Helper loaded: url_helper
DEBUG - 2014-03-05 00:55:49 --> this->setMessage()
DEBUG - 2014-03-05 00:55:50 --> File loaded: application/views/register.php
DEBUG - 2014-03-05 00:55:50 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 00:55:50 --> Final output sent to browser
DEBUG - 2014-03-05 00:55:50 --> Total execution time: 1.9244
DEBUG - 2014-03-05 00:55:50 --> Config Class Initialized
DEBUG - 2014-03-05 00:55:50 --> Hooks Class Initialized
DEBUG - 2014-03-05 00:55:50 --> Utf8 Class Initialized
DEBUG - 2014-03-05 00:55:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 00:55:51 --> URI Class Initialized
DEBUG - 2014-03-05 00:55:51 --> Router Class Initialized
DEBUG - 2014-03-05 00:55:51 --> Output Class Initialized
DEBUG - 2014-03-05 00:55:51 --> Security Class Initialized
DEBUG - 2014-03-05 00:55:51 --> Input Class Initialized
DEBUG - 2014-03-05 00:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 00:55:51 --> Language Class Initialized
DEBUG - 2014-03-05 00:55:51 --> Loader Class Initialized
DEBUG - 2014-03-05 00:55:51 --> Database Driver Class Initialized
DEBUG - 2014-03-05 00:55:51 --> Session Class Initialized
DEBUG - 2014-03-05 00:55:52 --> Helper loaded: string_helper
DEBUG - 2014-03-05 00:55:52 --> Session routines successfully run
DEBUG - 2014-03-05 00:55:52 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 00:55:52 --> User Agent Class Initialized
DEBUG - 2014-03-05 00:55:52 --> Controller Class Initialized
DEBUG - 2014-03-05 00:55:52 --> Helper loaded: url_helper
DEBUG - 2014-03-05 00:55:52 --> this->setMessage()
ERROR - 2014-03-05 00:55:52 --> 404 Page Not Found --> welcome/Controls
DEBUG - 2014-03-05 00:56:08 --> Config Class Initialized
DEBUG - 2014-03-05 00:56:09 --> Hooks Class Initialized
DEBUG - 2014-03-05 00:56:09 --> Utf8 Class Initialized
DEBUG - 2014-03-05 00:56:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 00:56:09 --> URI Class Initialized
DEBUG - 2014-03-05 00:56:09 --> Router Class Initialized
DEBUG - 2014-03-05 00:56:09 --> Output Class Initialized
DEBUG - 2014-03-05 00:56:09 --> Security Class Initialized
DEBUG - 2014-03-05 00:56:09 --> Input Class Initialized
DEBUG - 2014-03-05 00:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 00:56:09 --> Language Class Initialized
DEBUG - 2014-03-05 00:56:09 --> Loader Class Initialized
DEBUG - 2014-03-05 00:56:09 --> Database Driver Class Initialized
DEBUG - 2014-03-05 00:56:09 --> Session Class Initialized
DEBUG - 2014-03-05 00:56:09 --> Helper loaded: string_helper
DEBUG - 2014-03-05 00:56:09 --> Session routines successfully run
DEBUG - 2014-03-05 00:56:10 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 00:56:10 --> User Agent Class Initialized
DEBUG - 2014-03-05 00:56:10 --> Controller Class Initialized
DEBUG - 2014-03-05 00:56:10 --> Helper loaded: url_helper
DEBUG - 2014-03-05 00:56:10 --> this->setMessage()
DEBUG - 2014-03-05 00:56:10 --> File loaded: application/views/query.php
DEBUG - 2014-03-05 00:56:10 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 00:56:10 --> Final output sent to browser
DEBUG - 2014-03-05 00:56:10 --> Total execution time: 1.6792
DEBUG - 2014-03-05 00:56:11 --> Config Class Initialized
DEBUG - 2014-03-05 00:56:11 --> Hooks Class Initialized
DEBUG - 2014-03-05 00:56:11 --> Utf8 Class Initialized
DEBUG - 2014-03-05 00:56:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 00:56:11 --> URI Class Initialized
DEBUG - 2014-03-05 00:56:11 --> Router Class Initialized
DEBUG - 2014-03-05 00:56:11 --> Output Class Initialized
DEBUG - 2014-03-05 00:56:11 --> Security Class Initialized
DEBUG - 2014-03-05 00:56:12 --> Input Class Initialized
DEBUG - 2014-03-05 00:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 00:56:12 --> Language Class Initialized
DEBUG - 2014-03-05 00:56:12 --> Loader Class Initialized
DEBUG - 2014-03-05 00:56:12 --> Database Driver Class Initialized
DEBUG - 2014-03-05 00:56:12 --> Session Class Initialized
DEBUG - 2014-03-05 00:56:12 --> Helper loaded: string_helper
DEBUG - 2014-03-05 00:56:12 --> Session routines successfully run
DEBUG - 2014-03-05 00:56:12 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 00:56:12 --> User Agent Class Initialized
DEBUG - 2014-03-05 00:56:12 --> Controller Class Initialized
DEBUG - 2014-03-05 00:56:13 --> Helper loaded: url_helper
DEBUG - 2014-03-05 00:56:13 --> this->setMessage()
DEBUG - 2014-03-05 00:56:13 --> File loaded: application/views/register.php
DEBUG - 2014-03-05 00:56:13 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 00:56:13 --> Final output sent to browser
DEBUG - 2014-03-05 00:56:13 --> Total execution time: 2.0651
DEBUG - 2014-03-05 00:56:13 --> Config Class Initialized
DEBUG - 2014-03-05 00:56:13 --> Hooks Class Initialized
DEBUG - 2014-03-05 00:56:13 --> Utf8 Class Initialized
DEBUG - 2014-03-05 00:56:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 00:56:13 --> URI Class Initialized
DEBUG - 2014-03-05 00:56:13 --> Router Class Initialized
DEBUG - 2014-03-05 00:56:14 --> Output Class Initialized
DEBUG - 2014-03-05 00:56:14 --> Security Class Initialized
DEBUG - 2014-03-05 00:56:14 --> Input Class Initialized
DEBUG - 2014-03-05 00:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 00:56:14 --> Language Class Initialized
DEBUG - 2014-03-05 00:56:14 --> Loader Class Initialized
DEBUG - 2014-03-05 00:56:14 --> Database Driver Class Initialized
DEBUG - 2014-03-05 00:56:14 --> Session Class Initialized
DEBUG - 2014-03-05 00:56:14 --> Helper loaded: string_helper
DEBUG - 2014-03-05 00:56:14 --> Session routines successfully run
DEBUG - 2014-03-05 00:56:14 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 00:56:14 --> User Agent Class Initialized
DEBUG - 2014-03-05 00:56:15 --> Controller Class Initialized
DEBUG - 2014-03-05 00:56:15 --> Helper loaded: url_helper
DEBUG - 2014-03-05 00:56:15 --> this->setMessage()
ERROR - 2014-03-05 00:56:15 --> 404 Page Not Found --> welcome/Controls
DEBUG - 2014-03-05 00:58:39 --> Config Class Initialized
DEBUG - 2014-03-05 00:58:39 --> Hooks Class Initialized
DEBUG - 2014-03-05 00:58:39 --> Utf8 Class Initialized
DEBUG - 2014-03-05 00:58:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 00:58:39 --> URI Class Initialized
DEBUG - 2014-03-05 00:58:39 --> Router Class Initialized
DEBUG - 2014-03-05 00:58:39 --> Output Class Initialized
DEBUG - 2014-03-05 00:58:39 --> Security Class Initialized
DEBUG - 2014-03-05 00:58:39 --> Input Class Initialized
DEBUG - 2014-03-05 00:58:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 00:58:40 --> Language Class Initialized
DEBUG - 2014-03-05 00:58:40 --> Loader Class Initialized
DEBUG - 2014-03-05 00:58:40 --> Database Driver Class Initialized
DEBUG - 2014-03-05 00:58:40 --> Session Class Initialized
DEBUG - 2014-03-05 00:58:40 --> Helper loaded: string_helper
DEBUG - 2014-03-05 00:58:40 --> Session routines successfully run
DEBUG - 2014-03-05 00:58:40 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 00:58:40 --> User Agent Class Initialized
DEBUG - 2014-03-05 00:58:40 --> Controller Class Initialized
DEBUG - 2014-03-05 00:58:40 --> Helper loaded: url_helper
DEBUG - 2014-03-05 00:58:41 --> this->setMessage()
DEBUG - 2014-03-05 00:58:41 --> File loaded: application/views/register.php
DEBUG - 2014-03-05 00:58:41 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 00:58:41 --> Final output sent to browser
DEBUG - 2014-03-05 00:58:41 --> Total execution time: 1.7245
DEBUG - 2014-03-05 00:59:18 --> Config Class Initialized
DEBUG - 2014-03-05 00:59:18 --> Hooks Class Initialized
DEBUG - 2014-03-05 00:59:18 --> Utf8 Class Initialized
DEBUG - 2014-03-05 00:59:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 00:59:18 --> URI Class Initialized
DEBUG - 2014-03-05 00:59:18 --> Router Class Initialized
DEBUG - 2014-03-05 00:59:18 --> Output Class Initialized
DEBUG - 2014-03-05 00:59:19 --> Security Class Initialized
DEBUG - 2014-03-05 00:59:19 --> Input Class Initialized
DEBUG - 2014-03-05 00:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 00:59:19 --> Language Class Initialized
DEBUG - 2014-03-05 00:59:19 --> Loader Class Initialized
DEBUG - 2014-03-05 00:59:19 --> Database Driver Class Initialized
ERROR - 2014-03-05 00:59:19 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\www\nas\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-03-05 00:59:20 --> Session Class Initialized
DEBUG - 2014-03-05 00:59:20 --> Helper loaded: string_helper
DEBUG - 2014-03-05 00:59:20 --> Session routines successfully run
DEBUG - 2014-03-05 00:59:20 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 00:59:20 --> User Agent Class Initialized
DEBUG - 2014-03-05 00:59:20 --> Controller Class Initialized
DEBUG - 2014-03-05 00:59:21 --> Helper loaded: url_helper
DEBUG - 2014-03-05 00:59:21 --> this->setMessage()
DEBUG - 2014-03-05 00:59:21 --> File loaded: application/views/register.php
DEBUG - 2014-03-05 00:59:21 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 00:59:21 --> Final output sent to browser
DEBUG - 2014-03-05 00:59:21 --> Total execution time: 2.6144
DEBUG - 2014-03-05 14:38:37 --> Config Class Initialized
DEBUG - 2014-03-05 14:38:37 --> Hooks Class Initialized
DEBUG - 2014-03-05 14:38:37 --> Utf8 Class Initialized
DEBUG - 2014-03-05 14:38:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 14:38:37 --> URI Class Initialized
DEBUG - 2014-03-05 14:38:37 --> Router Class Initialized
DEBUG - 2014-03-05 14:38:37 --> No URI present. Default controller set.
DEBUG - 2014-03-05 14:38:37 --> Output Class Initialized
DEBUG - 2014-03-05 14:38:37 --> Security Class Initialized
DEBUG - 2014-03-05 14:38:37 --> Input Class Initialized
DEBUG - 2014-03-05 14:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 14:38:37 --> Language Class Initialized
DEBUG - 2014-03-05 14:38:37 --> Loader Class Initialized
DEBUG - 2014-03-05 14:38:37 --> Database Driver Class Initialized
DEBUG - 2014-03-05 14:38:38 --> Session Class Initialized
DEBUG - 2014-03-05 14:38:39 --> Helper loaded: string_helper
DEBUG - 2014-03-05 14:38:39 --> A session cookie was not found.
DEBUG - 2014-03-05 14:38:39 --> Session routines successfully run
DEBUG - 2014-03-05 14:38:39 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 14:38:39 --> User Agent Class Initialized
DEBUG - 2014-03-05 14:38:39 --> Controller Class Initialized
DEBUG - 2014-03-05 14:38:39 --> Helper loaded: url_helper
DEBUG - 2014-03-05 14:38:39 --> this->setMessage()
DEBUG - 2014-03-05 14:38:40 --> this->setMessage()
DEBUG - 2014-03-05 14:38:40 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 14:38:40 --> Final output sent to browser
DEBUG - 2014-03-05 14:38:40 --> Total execution time: 3.4570
DEBUG - 2014-03-05 14:40:04 --> Config Class Initialized
DEBUG - 2014-03-05 14:40:04 --> Hooks Class Initialized
DEBUG - 2014-03-05 14:40:04 --> Utf8 Class Initialized
DEBUG - 2014-03-05 14:40:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 14:40:05 --> URI Class Initialized
DEBUG - 2014-03-05 14:40:05 --> Router Class Initialized
DEBUG - 2014-03-05 14:40:05 --> No URI present. Default controller set.
DEBUG - 2014-03-05 14:40:05 --> Output Class Initialized
DEBUG - 2014-03-05 14:40:05 --> Security Class Initialized
DEBUG - 2014-03-05 14:40:05 --> Input Class Initialized
DEBUG - 2014-03-05 14:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 14:40:05 --> Language Class Initialized
DEBUG - 2014-03-05 14:40:05 --> Loader Class Initialized
DEBUG - 2014-03-05 14:40:05 --> Database Driver Class Initialized
DEBUG - 2014-03-05 14:40:06 --> Session Class Initialized
DEBUG - 2014-03-05 14:40:06 --> Helper loaded: string_helper
DEBUG - 2014-03-05 14:40:06 --> Session routines successfully run
DEBUG - 2014-03-05 14:40:06 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 14:40:06 --> User Agent Class Initialized
DEBUG - 2014-03-05 14:40:06 --> Controller Class Initialized
DEBUG - 2014-03-05 14:40:06 --> Helper loaded: url_helper
DEBUG - 2014-03-05 14:40:06 --> this->setMessage()
DEBUG - 2014-03-05 14:40:06 --> this->setMessage()
DEBUG - 2014-03-05 14:40:06 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 14:40:06 --> Final output sent to browser
DEBUG - 2014-03-05 14:40:06 --> Total execution time: 1.5654
DEBUG - 2014-03-05 14:41:20 --> Config Class Initialized
DEBUG - 2014-03-05 14:41:20 --> Hooks Class Initialized
DEBUG - 2014-03-05 14:41:20 --> Utf8 Class Initialized
DEBUG - 2014-03-05 14:41:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 14:41:20 --> URI Class Initialized
DEBUG - 2014-03-05 14:41:20 --> Router Class Initialized
DEBUG - 2014-03-05 14:41:20 --> Output Class Initialized
DEBUG - 2014-03-05 14:41:20 --> Security Class Initialized
DEBUG - 2014-03-05 14:41:20 --> Input Class Initialized
DEBUG - 2014-03-05 14:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 14:41:20 --> Language Class Initialized
DEBUG - 2014-03-05 14:41:20 --> Loader Class Initialized
DEBUG - 2014-03-05 14:41:20 --> Database Driver Class Initialized
DEBUG - 2014-03-05 14:41:21 --> Session Class Initialized
DEBUG - 2014-03-05 14:41:21 --> Helper loaded: string_helper
DEBUG - 2014-03-05 14:41:21 --> Session routines successfully run
DEBUG - 2014-03-05 14:41:21 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 14:41:21 --> User Agent Class Initialized
DEBUG - 2014-03-05 14:41:21 --> Controller Class Initialized
DEBUG - 2014-03-05 14:41:21 --> Helper loaded: url_helper
DEBUG - 2014-03-05 14:41:22 --> this->setMessage()
DEBUG - 2014-03-05 14:41:22 --> File loaded: application/views/query.php
DEBUG - 2014-03-05 14:41:22 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 14:41:22 --> Final output sent to browser
DEBUG - 2014-03-05 14:41:22 --> Total execution time: 1.6519
DEBUG - 2014-03-05 14:44:00 --> Config Class Initialized
DEBUG - 2014-03-05 14:44:00 --> Hooks Class Initialized
DEBUG - 2014-03-05 14:44:00 --> Utf8 Class Initialized
DEBUG - 2014-03-05 14:44:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 14:44:00 --> URI Class Initialized
DEBUG - 2014-03-05 14:44:00 --> Router Class Initialized
DEBUG - 2014-03-05 14:44:00 --> Output Class Initialized
DEBUG - 2014-03-05 14:44:00 --> Security Class Initialized
DEBUG - 2014-03-05 14:44:00 --> Input Class Initialized
DEBUG - 2014-03-05 14:44:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 14:44:00 --> Language Class Initialized
DEBUG - 2014-03-05 14:44:00 --> Loader Class Initialized
DEBUG - 2014-03-05 14:44:00 --> Database Driver Class Initialized
DEBUG - 2014-03-05 14:44:00 --> Session Class Initialized
DEBUG - 2014-03-05 14:44:00 --> Helper loaded: string_helper
DEBUG - 2014-03-05 14:44:00 --> Session routines successfully run
DEBUG - 2014-03-05 14:44:00 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 14:44:00 --> User Agent Class Initialized
DEBUG - 2014-03-05 14:44:00 --> Controller Class Initialized
DEBUG - 2014-03-05 14:44:00 --> Helper loaded: url_helper
DEBUG - 2014-03-05 14:44:01 --> Model Class Initialized
DEBUG - 2014-03-05 14:44:01 --> Final output sent to browser
DEBUG - 2014-03-05 14:44:01 --> Total execution time: 1.0087
DEBUG - 2014-03-05 14:44:03 --> Config Class Initialized
DEBUG - 2014-03-05 14:44:03 --> Hooks Class Initialized
DEBUG - 2014-03-05 14:44:03 --> Utf8 Class Initialized
DEBUG - 2014-03-05 14:44:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 14:44:04 --> URI Class Initialized
DEBUG - 2014-03-05 14:44:04 --> Router Class Initialized
DEBUG - 2014-03-05 14:44:04 --> Output Class Initialized
DEBUG - 2014-03-05 14:44:04 --> Security Class Initialized
DEBUG - 2014-03-05 14:44:04 --> Input Class Initialized
DEBUG - 2014-03-05 14:44:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 14:44:04 --> Language Class Initialized
DEBUG - 2014-03-05 14:44:04 --> Loader Class Initialized
DEBUG - 2014-03-05 14:44:04 --> Database Driver Class Initialized
DEBUG - 2014-03-05 14:44:04 --> Session Class Initialized
DEBUG - 2014-03-05 14:44:04 --> Helper loaded: string_helper
DEBUG - 2014-03-05 14:44:04 --> Session routines successfully run
DEBUG - 2014-03-05 14:44:04 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 14:44:04 --> User Agent Class Initialized
DEBUG - 2014-03-05 14:44:04 --> Controller Class Initialized
DEBUG - 2014-03-05 14:44:04 --> Helper loaded: url_helper
DEBUG - 2014-03-05 14:44:04 --> this->setMessage()
DEBUG - 2014-03-05 14:44:04 --> File loaded: application/views/register.php
DEBUG - 2014-03-05 14:44:04 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 14:44:04 --> Final output sent to browser
DEBUG - 2014-03-05 14:44:04 --> Total execution time: 0.8737
DEBUG - 2014-03-05 14:59:38 --> Config Class Initialized
DEBUG - 2014-03-05 14:59:38 --> Hooks Class Initialized
DEBUG - 2014-03-05 14:59:38 --> Utf8 Class Initialized
DEBUG - 2014-03-05 14:59:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 14:59:38 --> URI Class Initialized
DEBUG - 2014-03-05 14:59:38 --> Router Class Initialized
DEBUG - 2014-03-05 14:59:38 --> Output Class Initialized
DEBUG - 2014-03-05 14:59:38 --> Security Class Initialized
DEBUG - 2014-03-05 14:59:38 --> Input Class Initialized
DEBUG - 2014-03-05 14:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 14:59:38 --> Language Class Initialized
DEBUG - 2014-03-05 14:59:38 --> Loader Class Initialized
DEBUG - 2014-03-05 14:59:38 --> Database Driver Class Initialized
DEBUG - 2014-03-05 14:59:38 --> Session Class Initialized
DEBUG - 2014-03-05 14:59:38 --> Helper loaded: string_helper
DEBUG - 2014-03-05 14:59:38 --> Session routines successfully run
DEBUG - 2014-03-05 14:59:38 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 14:59:38 --> User Agent Class Initialized
DEBUG - 2014-03-05 14:59:38 --> Controller Class Initialized
DEBUG - 2014-03-05 14:59:38 --> Helper loaded: url_helper
DEBUG - 2014-03-05 14:59:38 --> this->setMessage()
DEBUG - 2014-03-05 14:59:38 --> File loaded: application/views/register.php
DEBUG - 2014-03-05 14:59:38 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 14:59:39 --> Final output sent to browser
DEBUG - 2014-03-05 14:59:39 --> Total execution time: 0.8085
DEBUG - 2014-03-05 15:00:46 --> Config Class Initialized
DEBUG - 2014-03-05 15:00:46 --> Hooks Class Initialized
DEBUG - 2014-03-05 15:00:46 --> Utf8 Class Initialized
DEBUG - 2014-03-05 15:00:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 15:00:46 --> URI Class Initialized
DEBUG - 2014-03-05 15:00:46 --> Router Class Initialized
DEBUG - 2014-03-05 15:00:46 --> Output Class Initialized
DEBUG - 2014-03-05 15:00:46 --> Security Class Initialized
DEBUG - 2014-03-05 15:00:46 --> Input Class Initialized
DEBUG - 2014-03-05 15:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 15:00:46 --> Language Class Initialized
DEBUG - 2014-03-05 15:00:46 --> Loader Class Initialized
DEBUG - 2014-03-05 15:00:46 --> Database Driver Class Initialized
DEBUG - 2014-03-05 15:00:46 --> Session Class Initialized
DEBUG - 2014-03-05 15:00:46 --> Helper loaded: string_helper
DEBUG - 2014-03-05 15:00:46 --> Session routines successfully run
DEBUG - 2014-03-05 15:00:46 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 15:00:46 --> User Agent Class Initialized
DEBUG - 2014-03-05 15:00:46 --> Controller Class Initialized
DEBUG - 2014-03-05 15:00:46 --> Helper loaded: url_helper
DEBUG - 2014-03-05 15:00:46 --> Model Class Initialized
DEBUG - 2014-03-05 15:00:46 --> Final output sent to browser
DEBUG - 2014-03-05 15:00:46 --> Total execution time: 0.4006
DEBUG - 2014-03-05 16:04:06 --> Config Class Initialized
DEBUG - 2014-03-05 16:04:06 --> Hooks Class Initialized
DEBUG - 2014-03-05 16:04:06 --> Utf8 Class Initialized
DEBUG - 2014-03-05 16:04:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 16:04:06 --> URI Class Initialized
DEBUG - 2014-03-05 16:04:06 --> Router Class Initialized
DEBUG - 2014-03-05 16:04:06 --> Output Class Initialized
DEBUG - 2014-03-05 16:04:06 --> Security Class Initialized
DEBUG - 2014-03-05 16:04:06 --> Input Class Initialized
DEBUG - 2014-03-05 16:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 16:04:06 --> Language Class Initialized
DEBUG - 2014-03-05 16:04:06 --> Loader Class Initialized
DEBUG - 2014-03-05 16:04:06 --> Database Driver Class Initialized
DEBUG - 2014-03-05 16:04:06 --> Session Class Initialized
DEBUG - 2014-03-05 16:04:06 --> Helper loaded: string_helper
DEBUG - 2014-03-05 16:04:06 --> Session routines successfully run
DEBUG - 2014-03-05 16:04:06 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 16:04:06 --> User Agent Class Initialized
DEBUG - 2014-03-05 16:04:06 --> Controller Class Initialized
DEBUG - 2014-03-05 16:04:06 --> Helper loaded: url_helper
DEBUG - 2014-03-05 16:04:07 --> this->setMessage()
DEBUG - 2014-03-05 16:04:07 --> File loaded: application/views/register.php
DEBUG - 2014-03-05 16:04:07 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 16:04:07 --> Final output sent to browser
DEBUG - 2014-03-05 16:04:07 --> Total execution time: 0.8310
DEBUG - 2014-03-05 16:04:07 --> Config Class Initialized
DEBUG - 2014-03-05 16:04:07 --> Hooks Class Initialized
DEBUG - 2014-03-05 16:04:07 --> Utf8 Class Initialized
DEBUG - 2014-03-05 16:04:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 16:04:07 --> URI Class Initialized
DEBUG - 2014-03-05 16:04:07 --> Router Class Initialized
DEBUG - 2014-03-05 16:04:07 --> Output Class Initialized
DEBUG - 2014-03-05 16:04:07 --> Security Class Initialized
DEBUG - 2014-03-05 16:04:07 --> Input Class Initialized
DEBUG - 2014-03-05 16:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 16:04:07 --> Language Class Initialized
DEBUG - 2014-03-05 16:04:11 --> Config Class Initialized
DEBUG - 2014-03-05 16:04:11 --> Hooks Class Initialized
DEBUG - 2014-03-05 16:04:11 --> Utf8 Class Initialized
DEBUG - 2014-03-05 16:04:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 16:04:11 --> URI Class Initialized
DEBUG - 2014-03-05 16:04:11 --> Router Class Initialized
DEBUG - 2014-03-05 16:04:12 --> Output Class Initialized
DEBUG - 2014-03-05 16:04:12 --> Security Class Initialized
DEBUG - 2014-03-05 16:04:12 --> Input Class Initialized
DEBUG - 2014-03-05 16:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 16:04:12 --> Language Class Initialized
DEBUG - 2014-03-05 16:04:12 --> Loader Class Initialized
DEBUG - 2014-03-05 16:04:12 --> Database Driver Class Initialized
DEBUG - 2014-03-05 16:04:12 --> Session Class Initialized
DEBUG - 2014-03-05 16:04:12 --> Helper loaded: string_helper
DEBUG - 2014-03-05 16:04:12 --> Session routines successfully run
DEBUG - 2014-03-05 16:04:12 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 16:04:12 --> User Agent Class Initialized
DEBUG - 2014-03-05 16:04:12 --> Controller Class Initialized
DEBUG - 2014-03-05 16:04:12 --> Helper loaded: url_helper
DEBUG - 2014-03-05 16:04:12 --> this->setMessage()
DEBUG - 2014-03-05 16:04:12 --> File loaded: application/views/register.php
DEBUG - 2014-03-05 16:04:12 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 16:04:12 --> Final output sent to browser
DEBUG - 2014-03-05 16:04:12 --> Total execution time: 0.6525
DEBUG - 2014-03-05 16:04:12 --> Config Class Initialized
DEBUG - 2014-03-05 16:04:12 --> Hooks Class Initialized
DEBUG - 2014-03-05 16:04:12 --> Utf8 Class Initialized
DEBUG - 2014-03-05 16:04:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 16:04:12 --> URI Class Initialized
DEBUG - 2014-03-05 16:04:12 --> Router Class Initialized
DEBUG - 2014-03-05 16:04:12 --> Output Class Initialized
DEBUG - 2014-03-05 16:04:12 --> Security Class Initialized
DEBUG - 2014-03-05 16:04:12 --> Input Class Initialized
DEBUG - 2014-03-05 16:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 16:04:12 --> Language Class Initialized
DEBUG - 2014-03-05 16:04:29 --> Config Class Initialized
DEBUG - 2014-03-05 16:04:29 --> Hooks Class Initialized
DEBUG - 2014-03-05 16:04:29 --> Utf8 Class Initialized
DEBUG - 2014-03-05 16:04:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 16:04:29 --> URI Class Initialized
DEBUG - 2014-03-05 16:04:29 --> Router Class Initialized
DEBUG - 2014-03-05 16:04:29 --> Output Class Initialized
DEBUG - 2014-03-05 16:04:29 --> Security Class Initialized
DEBUG - 2014-03-05 16:04:29 --> Input Class Initialized
DEBUG - 2014-03-05 16:04:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 16:04:29 --> Language Class Initialized
DEBUG - 2014-03-05 16:04:29 --> Loader Class Initialized
DEBUG - 2014-03-05 16:04:29 --> Database Driver Class Initialized
DEBUG - 2014-03-05 16:04:29 --> Session Class Initialized
DEBUG - 2014-03-05 16:04:29 --> Helper loaded: string_helper
DEBUG - 2014-03-05 16:04:29 --> Session routines successfully run
DEBUG - 2014-03-05 16:04:29 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 16:04:29 --> User Agent Class Initialized
DEBUG - 2014-03-05 16:04:29 --> Controller Class Initialized
DEBUG - 2014-03-05 16:04:29 --> Helper loaded: url_helper
DEBUG - 2014-03-05 16:04:29 --> this->setMessage()
DEBUG - 2014-03-05 16:04:29 --> File loaded: application/views/register.php
DEBUG - 2014-03-05 16:04:29 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 16:04:29 --> Final output sent to browser
DEBUG - 2014-03-05 16:04:29 --> Total execution time: 0.5352
DEBUG - 2014-03-05 16:04:30 --> Config Class Initialized
DEBUG - 2014-03-05 16:04:30 --> Hooks Class Initialized
DEBUG - 2014-03-05 16:04:30 --> Utf8 Class Initialized
DEBUG - 2014-03-05 16:04:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 16:04:30 --> URI Class Initialized
DEBUG - 2014-03-05 16:04:30 --> Router Class Initialized
DEBUG - 2014-03-05 16:04:30 --> Output Class Initialized
DEBUG - 2014-03-05 16:04:30 --> Security Class Initialized
DEBUG - 2014-03-05 16:04:30 --> Input Class Initialized
DEBUG - 2014-03-05 16:04:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 16:04:30 --> Language Class Initialized
DEBUG - 2014-03-05 16:04:55 --> Config Class Initialized
DEBUG - 2014-03-05 16:04:55 --> Hooks Class Initialized
DEBUG - 2014-03-05 16:04:55 --> Utf8 Class Initialized
DEBUG - 2014-03-05 16:04:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 16:04:55 --> URI Class Initialized
DEBUG - 2014-03-05 16:04:55 --> Router Class Initialized
DEBUG - 2014-03-05 16:04:55 --> Output Class Initialized
DEBUG - 2014-03-05 16:04:55 --> Security Class Initialized
DEBUG - 2014-03-05 16:04:55 --> Input Class Initialized
DEBUG - 2014-03-05 16:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 16:04:55 --> Language Class Initialized
DEBUG - 2014-03-05 16:04:55 --> Loader Class Initialized
DEBUG - 2014-03-05 16:04:55 --> Database Driver Class Initialized
DEBUG - 2014-03-05 16:04:55 --> Session Class Initialized
DEBUG - 2014-03-05 16:04:55 --> Helper loaded: string_helper
DEBUG - 2014-03-05 16:04:55 --> Session routines successfully run
DEBUG - 2014-03-05 16:04:55 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 16:04:55 --> User Agent Class Initialized
DEBUG - 2014-03-05 16:04:55 --> Controller Class Initialized
DEBUG - 2014-03-05 16:04:56 --> Helper loaded: url_helper
DEBUG - 2014-03-05 16:04:56 --> this->setMessage()
DEBUG - 2014-03-05 16:04:56 --> File loaded: application/views/register.php
DEBUG - 2014-03-05 16:04:56 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 16:04:56 --> Final output sent to browser
DEBUG - 2014-03-05 16:04:56 --> Total execution time: 0.5178
DEBUG - 2014-03-05 16:04:56 --> Config Class Initialized
DEBUG - 2014-03-05 16:04:56 --> Hooks Class Initialized
DEBUG - 2014-03-05 16:04:56 --> Utf8 Class Initialized
DEBUG - 2014-03-05 16:04:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 16:04:56 --> URI Class Initialized
DEBUG - 2014-03-05 16:04:56 --> Router Class Initialized
DEBUG - 2014-03-05 16:04:56 --> Output Class Initialized
DEBUG - 2014-03-05 16:04:56 --> Security Class Initialized
DEBUG - 2014-03-05 16:04:56 --> Input Class Initialized
DEBUG - 2014-03-05 16:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 16:04:56 --> Language Class Initialized
DEBUG - 2014-03-05 16:05:44 --> Config Class Initialized
DEBUG - 2014-03-05 16:05:44 --> Hooks Class Initialized
DEBUG - 2014-03-05 16:05:44 --> Utf8 Class Initialized
DEBUG - 2014-03-05 16:05:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 16:05:44 --> URI Class Initialized
DEBUG - 2014-03-05 16:05:44 --> Router Class Initialized
DEBUG - 2014-03-05 16:05:44 --> Output Class Initialized
DEBUG - 2014-03-05 16:05:44 --> Security Class Initialized
DEBUG - 2014-03-05 16:05:44 --> Input Class Initialized
DEBUG - 2014-03-05 16:05:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 16:05:44 --> Language Class Initialized
DEBUG - 2014-03-05 16:05:44 --> Loader Class Initialized
DEBUG - 2014-03-05 16:05:44 --> Database Driver Class Initialized
DEBUG - 2014-03-05 16:05:44 --> Session Class Initialized
DEBUG - 2014-03-05 16:05:44 --> Helper loaded: string_helper
DEBUG - 2014-03-05 16:05:44 --> Session routines successfully run
DEBUG - 2014-03-05 16:05:44 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 16:05:44 --> User Agent Class Initialized
DEBUG - 2014-03-05 16:05:44 --> Controller Class Initialized
DEBUG - 2014-03-05 16:05:44 --> Helper loaded: url_helper
DEBUG - 2014-03-05 16:05:44 --> this->setMessage()
DEBUG - 2014-03-05 16:05:44 --> File loaded: application/views/register.php
DEBUG - 2014-03-05 16:05:44 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 16:05:45 --> Final output sent to browser
DEBUG - 2014-03-05 16:05:45 --> Total execution time: 0.6058
DEBUG - 2014-03-05 16:05:45 --> Config Class Initialized
DEBUG - 2014-03-05 16:05:45 --> Hooks Class Initialized
DEBUG - 2014-03-05 16:05:45 --> Utf8 Class Initialized
DEBUG - 2014-03-05 16:05:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 16:05:45 --> URI Class Initialized
DEBUG - 2014-03-05 16:05:45 --> Router Class Initialized
DEBUG - 2014-03-05 16:05:45 --> Output Class Initialized
DEBUG - 2014-03-05 16:05:45 --> Security Class Initialized
DEBUG - 2014-03-05 16:05:45 --> Input Class Initialized
DEBUG - 2014-03-05 16:05:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 16:05:45 --> Language Class Initialized
DEBUG - 2014-03-05 16:06:57 --> Config Class Initialized
DEBUG - 2014-03-05 16:06:57 --> Hooks Class Initialized
DEBUG - 2014-03-05 16:06:57 --> Utf8 Class Initialized
DEBUG - 2014-03-05 16:06:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 16:06:57 --> URI Class Initialized
DEBUG - 2014-03-05 16:06:57 --> Router Class Initialized
DEBUG - 2014-03-05 16:06:57 --> Output Class Initialized
DEBUG - 2014-03-05 16:06:57 --> Security Class Initialized
DEBUG - 2014-03-05 16:06:57 --> Input Class Initialized
DEBUG - 2014-03-05 16:06:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 16:06:57 --> Language Class Initialized
DEBUG - 2014-03-05 16:06:57 --> Loader Class Initialized
DEBUG - 2014-03-05 16:06:57 --> Database Driver Class Initialized
DEBUG - 2014-03-05 16:06:57 --> Session Class Initialized
DEBUG - 2014-03-05 16:06:57 --> Helper loaded: string_helper
DEBUG - 2014-03-05 16:06:57 --> Session routines successfully run
DEBUG - 2014-03-05 16:06:57 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 16:06:57 --> User Agent Class Initialized
DEBUG - 2014-03-05 16:06:57 --> Controller Class Initialized
DEBUG - 2014-03-05 16:06:57 --> Helper loaded: url_helper
DEBUG - 2014-03-05 16:06:57 --> this->setMessage()
DEBUG - 2014-03-05 16:06:57 --> File loaded: application/views/register.php
DEBUG - 2014-03-05 16:06:58 --> File loaded: application/views/master.php
DEBUG - 2014-03-05 16:06:58 --> Final output sent to browser
DEBUG - 2014-03-05 16:06:58 --> Total execution time: 0.5313
DEBUG - 2014-03-05 16:06:58 --> Config Class Initialized
DEBUG - 2014-03-05 16:06:58 --> Hooks Class Initialized
DEBUG - 2014-03-05 16:06:58 --> Utf8 Class Initialized
DEBUG - 2014-03-05 16:06:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-05 16:06:58 --> URI Class Initialized
DEBUG - 2014-03-05 16:06:58 --> Router Class Initialized
DEBUG - 2014-03-05 16:06:58 --> Output Class Initialized
DEBUG - 2014-03-05 16:06:58 --> Security Class Initialized
DEBUG - 2014-03-05 16:06:58 --> Input Class Initialized
DEBUG - 2014-03-05 16:06:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-05 16:06:58 --> Language Class Initialized
DEBUG - 2014-03-05 16:06:58 --> Loader Class Initialized
DEBUG - 2014-03-05 16:06:58 --> Database Driver Class Initialized
DEBUG - 2014-03-05 16:06:58 --> Session Class Initialized
DEBUG - 2014-03-05 16:06:58 --> Helper loaded: string_helper
DEBUG - 2014-03-05 16:06:58 --> Session routines successfully run
DEBUG - 2014-03-05 16:06:58 --> XML-RPC Class Initialized
DEBUG - 2014-03-05 16:06:58 --> User Agent Class Initialized
DEBUG - 2014-03-05 16:06:58 --> Controller Class Initialized
DEBUG - 2014-03-05 16:06:58 --> Helper loaded: url_helper
DEBUG - 2014-03-05 16:06:58 --> Model Class Initialized
DEBUG - 2014-03-05 16:06:58 --> Final output sent to browser
DEBUG - 2014-03-05 16:06:59 --> Total execution time: 0.4781
