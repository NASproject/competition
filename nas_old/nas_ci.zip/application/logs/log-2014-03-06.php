<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-03-06 02:32:44 --> Config Class Initialized
DEBUG - 2014-03-06 02:32:44 --> Hooks Class Initialized
DEBUG - 2014-03-06 02:32:44 --> Utf8 Class Initialized
DEBUG - 2014-03-06 02:32:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 02:32:44 --> URI Class Initialized
DEBUG - 2014-03-06 02:32:44 --> Router Class Initialized
DEBUG - 2014-03-06 02:32:44 --> Output Class Initialized
DEBUG - 2014-03-06 02:32:44 --> Security Class Initialized
DEBUG - 2014-03-06 02:32:44 --> Input Class Initialized
DEBUG - 2014-03-06 02:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 02:32:44 --> Language Class Initialized
DEBUG - 2014-03-06 02:32:44 --> Loader Class Initialized
DEBUG - 2014-03-06 02:32:44 --> Database Driver Class Initialized
ERROR - 2014-03-06 02:32:44 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\www\nas\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-03-06 02:32:45 --> Session Class Initialized
DEBUG - 2014-03-06 02:32:45 --> Helper loaded: string_helper
DEBUG - 2014-03-06 02:32:45 --> A session cookie was not found.
DEBUG - 2014-03-06 02:32:45 --> Session routines successfully run
DEBUG - 2014-03-06 02:32:45 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 02:32:45 --> User Agent Class Initialized
DEBUG - 2014-03-06 02:32:46 --> Controller Class Initialized
DEBUG - 2014-03-06 02:32:46 --> Helper loaded: url_helper
DEBUG - 2014-03-06 02:32:46 --> this->setMessage()
DEBUG - 2014-03-06 02:32:46 --> File loaded: application/views/register.php
DEBUG - 2014-03-06 02:32:46 --> File loaded: application/views/master.php
DEBUG - 2014-03-06 02:32:46 --> Final output sent to browser
DEBUG - 2014-03-06 02:32:46 --> Total execution time: 1.6861
DEBUG - 2014-03-06 02:32:46 --> Config Class Initialized
DEBUG - 2014-03-06 02:32:46 --> Hooks Class Initialized
DEBUG - 2014-03-06 02:32:46 --> Utf8 Class Initialized
DEBUG - 2014-03-06 02:32:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 02:32:46 --> URI Class Initialized
DEBUG - 2014-03-06 02:32:46 --> Router Class Initialized
DEBUG - 2014-03-06 02:32:46 --> Output Class Initialized
DEBUG - 2014-03-06 02:32:46 --> Security Class Initialized
DEBUG - 2014-03-06 02:32:46 --> Input Class Initialized
DEBUG - 2014-03-06 02:32:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 02:32:46 --> Language Class Initialized
DEBUG - 2014-03-06 02:32:46 --> Loader Class Initialized
DEBUG - 2014-03-06 02:32:46 --> Database Driver Class Initialized
DEBUG - 2014-03-06 02:32:47 --> Session Class Initialized
DEBUG - 2014-03-06 02:32:47 --> Helper loaded: string_helper
DEBUG - 2014-03-06 02:32:47 --> Session routines successfully run
DEBUG - 2014-03-06 02:32:47 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 02:32:47 --> User Agent Class Initialized
DEBUG - 2014-03-06 02:32:47 --> Controller Class Initialized
DEBUG - 2014-03-06 02:32:47 --> Helper loaded: url_helper
DEBUG - 2014-03-06 02:32:47 --> Model Class Initialized
DEBUG - 2014-03-06 02:32:48 --> Final output sent to browser
DEBUG - 2014-03-06 02:32:48 --> Total execution time: 1.3865
DEBUG - 2014-03-06 02:37:24 --> Config Class Initialized
DEBUG - 2014-03-06 02:37:24 --> Hooks Class Initialized
DEBUG - 2014-03-06 02:37:24 --> Utf8 Class Initialized
DEBUG - 2014-03-06 02:37:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 02:37:24 --> URI Class Initialized
DEBUG - 2014-03-06 02:37:24 --> Router Class Initialized
DEBUG - 2014-03-06 02:37:24 --> No URI present. Default controller set.
DEBUG - 2014-03-06 02:37:24 --> Output Class Initialized
DEBUG - 2014-03-06 02:37:24 --> Security Class Initialized
DEBUG - 2014-03-06 02:37:24 --> Input Class Initialized
DEBUG - 2014-03-06 02:37:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 02:37:25 --> Language Class Initialized
DEBUG - 2014-03-06 02:37:25 --> Loader Class Initialized
DEBUG - 2014-03-06 02:37:25 --> Database Driver Class Initialized
ERROR - 2014-03-06 02:37:25 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\www\nas\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-03-06 02:37:26 --> Session Class Initialized
DEBUG - 2014-03-06 02:37:26 --> Helper loaded: string_helper
DEBUG - 2014-03-06 02:37:26 --> Session routines successfully run
DEBUG - 2014-03-06 02:37:26 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 02:37:26 --> User Agent Class Initialized
DEBUG - 2014-03-06 02:37:26 --> Controller Class Initialized
DEBUG - 2014-03-06 02:37:26 --> Helper loaded: url_helper
DEBUG - 2014-03-06 02:37:26 --> this->setMessage()
DEBUG - 2014-03-06 02:37:26 --> this->setMessage()
DEBUG - 2014-03-06 02:37:26 --> File loaded: application/views/master.php
DEBUG - 2014-03-06 02:37:26 --> Final output sent to browser
DEBUG - 2014-03-06 02:37:26 --> Total execution time: 1.5446
DEBUG - 2014-03-06 02:39:40 --> Config Class Initialized
DEBUG - 2014-03-06 02:39:40 --> Hooks Class Initialized
DEBUG - 2014-03-06 02:39:40 --> Utf8 Class Initialized
DEBUG - 2014-03-06 02:39:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 02:39:40 --> URI Class Initialized
DEBUG - 2014-03-06 02:39:40 --> Router Class Initialized
DEBUG - 2014-03-06 02:39:40 --> Output Class Initialized
DEBUG - 2014-03-06 02:39:40 --> Security Class Initialized
DEBUG - 2014-03-06 02:39:40 --> Input Class Initialized
DEBUG - 2014-03-06 02:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 02:39:40 --> Language Class Initialized
DEBUG - 2014-03-06 02:39:40 --> Loader Class Initialized
DEBUG - 2014-03-06 02:39:40 --> Database Driver Class Initialized
ERROR - 2014-03-06 02:39:40 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\www\nas\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-03-06 02:39:41 --> Session Class Initialized
DEBUG - 2014-03-06 02:39:41 --> Helper loaded: string_helper
DEBUG - 2014-03-06 02:39:41 --> Session routines successfully run
DEBUG - 2014-03-06 02:39:41 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 02:39:41 --> User Agent Class Initialized
DEBUG - 2014-03-06 02:39:41 --> Controller Class Initialized
DEBUG - 2014-03-06 02:39:41 --> Helper loaded: url_helper
DEBUG - 2014-03-06 02:39:41 --> this->setMessage()
DEBUG - 2014-03-06 10:39:41 --> File loaded: application/views/query.php
DEBUG - 2014-03-06 10:39:41 --> File loaded: application/views/master.php
DEBUG - 2014-03-06 10:39:41 --> Final output sent to browser
DEBUG - 2014-03-06 10:39:41 --> Total execution time: 1.5393
DEBUG - 2014-03-06 02:42:37 --> Config Class Initialized
DEBUG - 2014-03-06 02:42:37 --> Hooks Class Initialized
DEBUG - 2014-03-06 02:42:37 --> Utf8 Class Initialized
DEBUG - 2014-03-06 02:42:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 02:42:37 --> URI Class Initialized
DEBUG - 2014-03-06 02:42:37 --> Router Class Initialized
DEBUG - 2014-03-06 02:42:37 --> Output Class Initialized
DEBUG - 2014-03-06 02:42:37 --> Security Class Initialized
DEBUG - 2014-03-06 02:42:37 --> Input Class Initialized
DEBUG - 2014-03-06 02:42:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 02:42:37 --> Language Class Initialized
DEBUG - 2014-03-06 02:42:37 --> Loader Class Initialized
DEBUG - 2014-03-06 02:42:37 --> Database Driver Class Initialized
DEBUG - 2014-03-06 02:42:38 --> Session Class Initialized
DEBUG - 2014-03-06 02:42:38 --> Helper loaded: string_helper
DEBUG - 2014-03-06 02:42:38 --> Session routines successfully run
DEBUG - 2014-03-06 02:42:38 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 02:42:38 --> User Agent Class Initialized
DEBUG - 2014-03-06 02:42:38 --> Controller Class Initialized
DEBUG - 2014-03-06 02:42:38 --> Helper loaded: url_helper
DEBUG - 2014-03-06 02:42:38 --> this->setMessage()
DEBUG - 2014-03-06 10:42:38 --> File loaded: application/views/register.php
DEBUG - 2014-03-06 10:42:39 --> File loaded: application/views/master.php
DEBUG - 2014-03-06 10:42:39 --> Final output sent to browser
DEBUG - 2014-03-06 10:42:39 --> Total execution time: 1.3491
DEBUG - 2014-03-06 02:42:39 --> Config Class Initialized
DEBUG - 2014-03-06 02:42:39 --> Hooks Class Initialized
DEBUG - 2014-03-06 02:42:39 --> Utf8 Class Initialized
DEBUG - 2014-03-06 02:42:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 02:42:39 --> URI Class Initialized
DEBUG - 2014-03-06 02:42:39 --> Router Class Initialized
DEBUG - 2014-03-06 02:42:39 --> Output Class Initialized
DEBUG - 2014-03-06 02:42:39 --> Security Class Initialized
DEBUG - 2014-03-06 02:42:39 --> Input Class Initialized
DEBUG - 2014-03-06 02:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 02:42:39 --> Language Class Initialized
DEBUG - 2014-03-06 02:42:39 --> Loader Class Initialized
DEBUG - 2014-03-06 02:42:39 --> Database Driver Class Initialized
DEBUG - 2014-03-06 02:42:39 --> Session Class Initialized
DEBUG - 2014-03-06 02:42:39 --> Helper loaded: string_helper
DEBUG - 2014-03-06 02:42:39 --> Session routines successfully run
DEBUG - 2014-03-06 02:42:39 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 02:42:39 --> User Agent Class Initialized
DEBUG - 2014-03-06 02:42:39 --> Controller Class Initialized
DEBUG - 2014-03-06 02:42:39 --> Helper loaded: url_helper
DEBUG - 2014-03-06 02:42:39 --> Model Class Initialized
DEBUG - 2014-03-06 10:42:39 --> Final output sent to browser
DEBUG - 2014-03-06 10:42:39 --> Total execution time: 0.4028
DEBUG - 2014-03-06 02:42:41 --> Config Class Initialized
DEBUG - 2014-03-06 02:42:41 --> Hooks Class Initialized
DEBUG - 2014-03-06 02:42:41 --> Utf8 Class Initialized
DEBUG - 2014-03-06 02:42:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 02:42:41 --> URI Class Initialized
DEBUG - 2014-03-06 02:42:41 --> Router Class Initialized
DEBUG - 2014-03-06 02:42:41 --> Output Class Initialized
DEBUG - 2014-03-06 02:42:41 --> Security Class Initialized
DEBUG - 2014-03-06 02:42:41 --> Input Class Initialized
DEBUG - 2014-03-06 02:42:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 02:42:41 --> Language Class Initialized
DEBUG - 2014-03-06 02:42:41 --> Loader Class Initialized
DEBUG - 2014-03-06 02:42:41 --> Database Driver Class Initialized
DEBUG - 2014-03-06 02:42:41 --> Session Class Initialized
DEBUG - 2014-03-06 02:42:41 --> Helper loaded: string_helper
DEBUG - 2014-03-06 02:42:41 --> Session routines successfully run
DEBUG - 2014-03-06 02:42:41 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 02:42:41 --> User Agent Class Initialized
DEBUG - 2014-03-06 02:42:41 --> Controller Class Initialized
DEBUG - 2014-03-06 02:42:41 --> Helper loaded: url_helper
DEBUG - 2014-03-06 02:42:41 --> this->setMessage()
DEBUG - 2014-03-06 10:42:41 --> File loaded: application/views/register.php
DEBUG - 2014-03-06 10:42:41 --> File loaded: application/views/master.php
DEBUG - 2014-03-06 10:42:41 --> Final output sent to browser
DEBUG - 2014-03-06 10:42:42 --> Total execution time: 0.5824
DEBUG - 2014-03-06 02:42:42 --> Config Class Initialized
DEBUG - 2014-03-06 02:42:42 --> Hooks Class Initialized
DEBUG - 2014-03-06 02:42:42 --> Utf8 Class Initialized
DEBUG - 2014-03-06 02:42:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 02:42:42 --> URI Class Initialized
DEBUG - 2014-03-06 02:42:42 --> Router Class Initialized
DEBUG - 2014-03-06 02:42:42 --> Output Class Initialized
DEBUG - 2014-03-06 02:42:42 --> Security Class Initialized
DEBUG - 2014-03-06 02:42:42 --> Input Class Initialized
DEBUG - 2014-03-06 02:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 02:42:42 --> Language Class Initialized
DEBUG - 2014-03-06 02:42:42 --> Loader Class Initialized
DEBUG - 2014-03-06 02:42:42 --> Database Driver Class Initialized
DEBUG - 2014-03-06 02:42:42 --> Session Class Initialized
DEBUG - 2014-03-06 02:42:42 --> Helper loaded: string_helper
DEBUG - 2014-03-06 02:42:42 --> Session routines successfully run
DEBUG - 2014-03-06 02:42:42 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 02:42:42 --> User Agent Class Initialized
DEBUG - 2014-03-06 02:42:42 --> Controller Class Initialized
DEBUG - 2014-03-06 02:42:42 --> Helper loaded: url_helper
DEBUG - 2014-03-06 02:42:42 --> Model Class Initialized
DEBUG - 2014-03-06 10:42:42 --> Final output sent to browser
DEBUG - 2014-03-06 10:42:42 --> Total execution time: 0.4101
DEBUG - 2014-03-06 02:48:13 --> Config Class Initialized
DEBUG - 2014-03-06 02:48:13 --> Hooks Class Initialized
DEBUG - 2014-03-06 02:48:13 --> Utf8 Class Initialized
DEBUG - 2014-03-06 02:48:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 02:48:13 --> URI Class Initialized
DEBUG - 2014-03-06 02:48:13 --> Router Class Initialized
DEBUG - 2014-03-06 02:48:13 --> Output Class Initialized
DEBUG - 2014-03-06 02:48:13 --> Security Class Initialized
DEBUG - 2014-03-06 02:48:13 --> Input Class Initialized
DEBUG - 2014-03-06 02:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 02:48:13 --> Language Class Initialized
DEBUG - 2014-03-06 02:48:13 --> Loader Class Initialized
DEBUG - 2014-03-06 02:48:13 --> Database Driver Class Initialized
DEBUG - 2014-03-06 02:48:13 --> Session Class Initialized
DEBUG - 2014-03-06 02:48:13 --> Helper loaded: string_helper
DEBUG - 2014-03-06 02:48:13 --> Session routines successfully run
DEBUG - 2014-03-06 02:48:13 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 02:48:13 --> User Agent Class Initialized
DEBUG - 2014-03-06 02:48:13 --> Controller Class Initialized
DEBUG - 2014-03-06 02:48:13 --> Helper loaded: url_helper
DEBUG - 2014-03-06 02:48:14 --> this->setMessage()
DEBUG - 2014-03-06 10:48:14 --> File loaded: application/views/register.php
DEBUG - 2014-03-06 10:48:14 --> File loaded: application/views/master.php
DEBUG - 2014-03-06 10:48:14 --> Final output sent to browser
DEBUG - 2014-03-06 10:48:14 --> Total execution time: 0.5527
DEBUG - 2014-03-06 02:48:14 --> Config Class Initialized
DEBUG - 2014-03-06 02:48:14 --> Hooks Class Initialized
DEBUG - 2014-03-06 02:48:14 --> Utf8 Class Initialized
DEBUG - 2014-03-06 02:48:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 02:48:14 --> URI Class Initialized
DEBUG - 2014-03-06 02:48:14 --> Router Class Initialized
DEBUG - 2014-03-06 02:48:14 --> Output Class Initialized
DEBUG - 2014-03-06 02:48:14 --> Security Class Initialized
DEBUG - 2014-03-06 02:48:14 --> Input Class Initialized
DEBUG - 2014-03-06 02:48:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 02:48:14 --> Language Class Initialized
DEBUG - 2014-03-06 02:48:14 --> Loader Class Initialized
DEBUG - 2014-03-06 02:48:14 --> Database Driver Class Initialized
DEBUG - 2014-03-06 02:48:14 --> Session Class Initialized
DEBUG - 2014-03-06 02:48:14 --> Helper loaded: string_helper
DEBUG - 2014-03-06 02:48:14 --> Session routines successfully run
DEBUG - 2014-03-06 02:48:14 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 02:48:14 --> User Agent Class Initialized
DEBUG - 2014-03-06 02:48:14 --> Controller Class Initialized
DEBUG - 2014-03-06 02:48:14 --> Helper loaded: url_helper
DEBUG - 2014-03-06 02:48:14 --> Model Class Initialized
DEBUG - 2014-03-06 10:48:14 --> Final output sent to browser
DEBUG - 2014-03-06 10:48:15 --> Total execution time: 0.4145
DEBUG - 2014-03-06 02:50:36 --> Config Class Initialized
DEBUG - 2014-03-06 02:50:36 --> Hooks Class Initialized
DEBUG - 2014-03-06 02:50:36 --> Utf8 Class Initialized
DEBUG - 2014-03-06 02:50:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 02:50:36 --> URI Class Initialized
DEBUG - 2014-03-06 02:50:36 --> Router Class Initialized
DEBUG - 2014-03-06 02:50:36 --> Output Class Initialized
DEBUG - 2014-03-06 02:50:36 --> Security Class Initialized
DEBUG - 2014-03-06 02:50:36 --> Input Class Initialized
DEBUG - 2014-03-06 02:50:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 02:50:36 --> Language Class Initialized
DEBUG - 2014-03-06 02:50:36 --> Loader Class Initialized
DEBUG - 2014-03-06 02:50:36 --> Database Driver Class Initialized
DEBUG - 2014-03-06 02:50:36 --> Session Class Initialized
DEBUG - 2014-03-06 02:50:36 --> Helper loaded: string_helper
DEBUG - 2014-03-06 02:50:36 --> Session routines successfully run
DEBUG - 2014-03-06 02:50:36 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 02:50:36 --> User Agent Class Initialized
DEBUG - 2014-03-06 02:50:36 --> Controller Class Initialized
DEBUG - 2014-03-06 02:50:36 --> Helper loaded: url_helper
DEBUG - 2014-03-06 02:50:37 --> Model Class Initialized
ERROR - 2014-03-06 10:50:37 --> Severity: Notice  --> Undefined index: name C:\wamp\www\nas\application\controllers\register.php 36
DEBUG - 2014-03-06 10:50:37 --> DB Transaction Failure
ERROR - 2014-03-06 10:50:37 --> Query error: Column 'p_adviser' cannot be null
DEBUG - 2014-03-06 10:50:37 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 02:54:22 --> Config Class Initialized
DEBUG - 2014-03-06 02:54:22 --> Hooks Class Initialized
DEBUG - 2014-03-06 02:54:22 --> Utf8 Class Initialized
DEBUG - 2014-03-06 02:54:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 02:54:22 --> URI Class Initialized
DEBUG - 2014-03-06 02:54:22 --> Router Class Initialized
DEBUG - 2014-03-06 02:54:22 --> Output Class Initialized
DEBUG - 2014-03-06 02:54:22 --> Security Class Initialized
DEBUG - 2014-03-06 02:54:22 --> Input Class Initialized
DEBUG - 2014-03-06 02:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 02:54:22 --> Language Class Initialized
DEBUG - 2014-03-06 02:54:22 --> Loader Class Initialized
DEBUG - 2014-03-06 02:54:22 --> Database Driver Class Initialized
DEBUG - 2014-03-06 02:54:22 --> Session Class Initialized
DEBUG - 2014-03-06 02:54:22 --> Helper loaded: string_helper
DEBUG - 2014-03-06 02:54:22 --> Session routines successfully run
DEBUG - 2014-03-06 02:54:22 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 02:54:22 --> User Agent Class Initialized
DEBUG - 2014-03-06 02:54:22 --> Controller Class Initialized
DEBUG - 2014-03-06 02:54:22 --> Helper loaded: url_helper
DEBUG - 2014-03-06 02:54:22 --> Model Class Initialized
ERROR - 2014-03-06 10:54:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\nas\application\controllers\register.php 36
DEBUG - 2014-03-06 10:54:22 --> DB Transaction Failure
ERROR - 2014-03-06 10:54:23 --> Query error: Column 'p_adviser' cannot be null
DEBUG - 2014-03-06 10:54:23 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 02:57:16 --> Config Class Initialized
DEBUG - 2014-03-06 02:57:16 --> Hooks Class Initialized
DEBUG - 2014-03-06 02:57:16 --> Utf8 Class Initialized
DEBUG - 2014-03-06 02:57:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 02:57:16 --> URI Class Initialized
DEBUG - 2014-03-06 02:57:16 --> Router Class Initialized
DEBUG - 2014-03-06 02:57:16 --> Output Class Initialized
DEBUG - 2014-03-06 02:57:16 --> Security Class Initialized
DEBUG - 2014-03-06 02:57:16 --> Input Class Initialized
DEBUG - 2014-03-06 02:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 02:57:16 --> Language Class Initialized
DEBUG - 2014-03-06 02:57:16 --> Loader Class Initialized
DEBUG - 2014-03-06 02:57:16 --> Database Driver Class Initialized
DEBUG - 2014-03-06 02:57:16 --> Session Class Initialized
DEBUG - 2014-03-06 02:57:17 --> Helper loaded: string_helper
DEBUG - 2014-03-06 02:57:17 --> Session routines successfully run
DEBUG - 2014-03-06 02:57:17 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 02:57:17 --> User Agent Class Initialized
DEBUG - 2014-03-06 02:57:17 --> Controller Class Initialized
DEBUG - 2014-03-06 02:57:17 --> Helper loaded: url_helper
DEBUG - 2014-03-06 02:57:17 --> Model Class Initialized
ERROR - 2014-03-06 10:57:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\nas\application\controllers\register.php 36
DEBUG - 2014-03-06 10:57:17 --> DB Transaction Failure
ERROR - 2014-03-06 10:57:17 --> Query error: Column 'p_adviser' cannot be null
DEBUG - 2014-03-06 10:57:17 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 02:59:17 --> Config Class Initialized
DEBUG - 2014-03-06 02:59:17 --> Hooks Class Initialized
DEBUG - 2014-03-06 02:59:17 --> Utf8 Class Initialized
DEBUG - 2014-03-06 02:59:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 02:59:17 --> URI Class Initialized
DEBUG - 2014-03-06 02:59:17 --> Router Class Initialized
DEBUG - 2014-03-06 02:59:17 --> Output Class Initialized
DEBUG - 2014-03-06 02:59:17 --> Security Class Initialized
DEBUG - 2014-03-06 02:59:17 --> Input Class Initialized
DEBUG - 2014-03-06 02:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 02:59:17 --> Language Class Initialized
DEBUG - 2014-03-06 02:59:17 --> Loader Class Initialized
DEBUG - 2014-03-06 02:59:17 --> Database Driver Class Initialized
DEBUG - 2014-03-06 02:59:17 --> Session Class Initialized
DEBUG - 2014-03-06 02:59:17 --> Helper loaded: string_helper
DEBUG - 2014-03-06 02:59:17 --> Session routines successfully run
DEBUG - 2014-03-06 02:59:17 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 02:59:17 --> User Agent Class Initialized
DEBUG - 2014-03-06 02:59:17 --> Controller Class Initialized
DEBUG - 2014-03-06 02:59:17 --> Helper loaded: url_helper
DEBUG - 2014-03-06 02:59:17 --> Model Class Initialized
DEBUG - 2014-03-06 10:59:17 --> DB Transaction Failure
ERROR - 2014-03-06 10:59:17 --> Query error: Column 'log_message' cannot be null
DEBUG - 2014-03-06 10:59:17 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:02:03 --> Config Class Initialized
DEBUG - 2014-03-06 03:02:03 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:02:03 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:02:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:02:03 --> URI Class Initialized
DEBUG - 2014-03-06 03:02:03 --> Router Class Initialized
DEBUG - 2014-03-06 03:02:03 --> Output Class Initialized
DEBUG - 2014-03-06 03:02:03 --> Security Class Initialized
DEBUG - 2014-03-06 03:02:03 --> Input Class Initialized
DEBUG - 2014-03-06 03:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:02:03 --> Language Class Initialized
DEBUG - 2014-03-06 03:02:03 --> Loader Class Initialized
DEBUG - 2014-03-06 03:02:03 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:02:03 --> Session Class Initialized
DEBUG - 2014-03-06 03:02:03 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:02:03 --> Session routines successfully run
DEBUG - 2014-03-06 03:02:03 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:02:03 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:02:03 --> Controller Class Initialized
DEBUG - 2014-03-06 03:02:03 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:02:03 --> Model Class Initialized
DEBUG - 2014-03-06 11:02:04 --> DB Transaction Failure
ERROR - 2014-03-06 11:02:04 --> Query error: Column 'log_message' cannot be null
DEBUG - 2014-03-06 11:02:04 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:03:57 --> Config Class Initialized
DEBUG - 2014-03-06 03:03:57 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:03:57 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:03:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:03:57 --> URI Class Initialized
DEBUG - 2014-03-06 03:03:57 --> Router Class Initialized
DEBUG - 2014-03-06 03:03:57 --> Output Class Initialized
DEBUG - 2014-03-06 03:03:57 --> Security Class Initialized
DEBUG - 2014-03-06 03:03:57 --> Input Class Initialized
DEBUG - 2014-03-06 03:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:03:57 --> Language Class Initialized
DEBUG - 2014-03-06 03:03:57 --> Loader Class Initialized
DEBUG - 2014-03-06 03:03:57 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:03:57 --> Session Class Initialized
DEBUG - 2014-03-06 03:03:57 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:03:57 --> Session routines successfully run
DEBUG - 2014-03-06 03:03:57 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:03:57 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:03:57 --> Controller Class Initialized
DEBUG - 2014-03-06 03:03:57 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:03:57 --> Model Class Initialized
DEBUG - 2014-03-06 11:03:57 --> var_dump(array('id' => 5))
ERROR - 2014-03-06 11:03:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\nas\application\controllers\register.php 36
DEBUG - 2014-03-06 11:03:57 --> DB Transaction Failure
ERROR - 2014-03-06 11:03:57 --> Query error: Column 'p_adviser' cannot be null
DEBUG - 2014-03-06 11:03:57 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:05:16 --> Config Class Initialized
DEBUG - 2014-03-06 03:05:16 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:05:16 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:05:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:05:16 --> URI Class Initialized
DEBUG - 2014-03-06 03:05:16 --> Router Class Initialized
DEBUG - 2014-03-06 03:05:16 --> Output Class Initialized
DEBUG - 2014-03-06 03:05:16 --> Security Class Initialized
DEBUG - 2014-03-06 03:05:16 --> Input Class Initialized
DEBUG - 2014-03-06 03:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:05:16 --> Language Class Initialized
DEBUG - 2014-03-06 03:05:16 --> Loader Class Initialized
DEBUG - 2014-03-06 03:05:16 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:05:16 --> Session Class Initialized
DEBUG - 2014-03-06 03:05:16 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:05:16 --> Session routines successfully run
DEBUG - 2014-03-06 03:05:16 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:05:16 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:05:16 --> Controller Class Initialized
DEBUG - 2014-03-06 03:05:16 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:05:16 --> Model Class Initialized
ERROR - 2014-03-06 11:05:16 --> Severity: Notice  --> Array to string conversion C:\wamp\www\nas\application\models\teacher_model.php 15
DEBUG - 2014-03-06 11:05:17 --> Array()
ERROR - 2014-03-06 11:05:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\nas\application\controllers\register.php 36
DEBUG - 2014-03-06 11:05:17 --> DB Transaction Failure
ERROR - 2014-03-06 11:05:17 --> Query error: Column 'p_adviser' cannot be null
DEBUG - 2014-03-06 11:05:17 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:06:11 --> Config Class Initialized
DEBUG - 2014-03-06 03:06:11 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:06:11 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:06:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:06:11 --> URI Class Initialized
DEBUG - 2014-03-06 03:06:11 --> Router Class Initialized
DEBUG - 2014-03-06 03:06:11 --> Output Class Initialized
DEBUG - 2014-03-06 03:06:11 --> Security Class Initialized
DEBUG - 2014-03-06 03:06:11 --> Input Class Initialized
DEBUG - 2014-03-06 03:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:06:11 --> Language Class Initialized
DEBUG - 2014-03-06 03:06:11 --> Loader Class Initialized
DEBUG - 2014-03-06 03:06:11 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:06:11 --> Session Class Initialized
DEBUG - 2014-03-06 03:06:11 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:06:11 --> Session routines successfully run
DEBUG - 2014-03-06 03:06:11 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:06:11 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:06:11 --> Controller Class Initialized
DEBUG - 2014-03-06 03:06:11 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:06:11 --> Model Class Initialized
ERROR - 2014-03-06 11:06:11 --> Severity: Notice  --> Array to string conversion C:\wamp\www\nas\application\models\teacher_model.php 15
DEBUG - 2014-03-06 11:06:12 --> var_dump(Array())
ERROR - 2014-03-06 11:06:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\nas\application\controllers\register.php 36
DEBUG - 2014-03-06 11:06:12 --> DB Transaction Failure
ERROR - 2014-03-06 11:06:12 --> Query error: Column 'p_adviser' cannot be null
DEBUG - 2014-03-06 11:06:12 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:07:08 --> Config Class Initialized
DEBUG - 2014-03-06 03:07:08 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:07:08 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:07:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:07:08 --> URI Class Initialized
DEBUG - 2014-03-06 03:07:08 --> Router Class Initialized
DEBUG - 2014-03-06 03:07:08 --> Output Class Initialized
DEBUG - 2014-03-06 03:07:08 --> Security Class Initialized
DEBUG - 2014-03-06 03:07:08 --> Input Class Initialized
DEBUG - 2014-03-06 03:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:07:08 --> Language Class Initialized
DEBUG - 2014-03-06 03:07:08 --> Loader Class Initialized
DEBUG - 2014-03-06 03:07:08 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:07:08 --> Session Class Initialized
DEBUG - 2014-03-06 03:07:08 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:07:08 --> Session routines successfully run
DEBUG - 2014-03-06 03:07:08 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:07:08 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:07:08 --> Controller Class Initialized
DEBUG - 2014-03-06 03:07:08 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:07:08 --> Model Class Initialized
DEBUG - 2014-03-06 11:07:08 --> DB Transaction Failure
ERROR - 2014-03-06 11:07:08 --> Query error: Column 'log_message' cannot be null
DEBUG - 2014-03-06 11:07:08 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:08:08 --> Config Class Initialized
DEBUG - 2014-03-06 03:08:08 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:08:08 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:08:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:08:08 --> URI Class Initialized
DEBUG - 2014-03-06 03:08:08 --> Router Class Initialized
DEBUG - 2014-03-06 03:08:09 --> Output Class Initialized
DEBUG - 2014-03-06 03:08:09 --> Security Class Initialized
DEBUG - 2014-03-06 03:08:09 --> Input Class Initialized
DEBUG - 2014-03-06 03:08:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:08:09 --> Language Class Initialized
DEBUG - 2014-03-06 03:08:09 --> Loader Class Initialized
DEBUG - 2014-03-06 03:08:09 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:08:09 --> Session Class Initialized
DEBUG - 2014-03-06 03:08:09 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:08:09 --> Session routines successfully run
DEBUG - 2014-03-06 03:08:09 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:08:09 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:08:09 --> Controller Class Initialized
DEBUG - 2014-03-06 03:08:09 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:08:09 --> Model Class Initialized
DEBUG - 2014-03-06 11:08:09 --> 1
ERROR - 2014-03-06 11:08:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\nas\application\controllers\register.php 36
DEBUG - 2014-03-06 11:08:09 --> DB Transaction Failure
ERROR - 2014-03-06 11:08:09 --> Query error: Column 'p_adviser' cannot be null
DEBUG - 2014-03-06 11:08:09 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:10:53 --> Config Class Initialized
DEBUG - 2014-03-06 03:10:53 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:10:53 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:10:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:10:53 --> URI Class Initialized
DEBUG - 2014-03-06 03:10:53 --> Router Class Initialized
DEBUG - 2014-03-06 03:10:53 --> Output Class Initialized
DEBUG - 2014-03-06 03:10:53 --> Security Class Initialized
DEBUG - 2014-03-06 03:10:53 --> Input Class Initialized
DEBUG - 2014-03-06 03:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:10:53 --> Language Class Initialized
DEBUG - 2014-03-06 03:10:53 --> Loader Class Initialized
DEBUG - 2014-03-06 03:10:53 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:10:53 --> Session Class Initialized
DEBUG - 2014-03-06 03:10:53 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:10:53 --> Session routines successfully run
DEBUG - 2014-03-06 03:10:53 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:10:53 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:10:53 --> Controller Class Initialized
DEBUG - 2014-03-06 03:10:53 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:10:53 --> Model Class Initialized
DEBUG - 2014-03-06 11:10:53 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
ERROR - 2014-03-06 11:10:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\nas\application\controllers\register.php 36
DEBUG - 2014-03-06 11:10:54 --> DB Transaction Failure
ERROR - 2014-03-06 11:10:54 --> Query error: Column 'p_adviser' cannot be null
DEBUG - 2014-03-06 11:10:54 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:11:48 --> Config Class Initialized
DEBUG - 2014-03-06 03:11:48 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:11:48 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:11:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:11:48 --> URI Class Initialized
DEBUG - 2014-03-06 03:11:48 --> Router Class Initialized
DEBUG - 2014-03-06 03:11:48 --> Output Class Initialized
DEBUG - 2014-03-06 03:11:48 --> Security Class Initialized
DEBUG - 2014-03-06 03:11:48 --> Input Class Initialized
DEBUG - 2014-03-06 03:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:11:48 --> Language Class Initialized
DEBUG - 2014-03-06 03:11:48 --> Loader Class Initialized
DEBUG - 2014-03-06 03:11:48 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:11:48 --> Session Class Initialized
DEBUG - 2014-03-06 03:11:48 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:11:48 --> Session routines successfully run
DEBUG - 2014-03-06 03:11:48 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:11:48 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:11:48 --> Controller Class Initialized
DEBUG - 2014-03-06 03:11:48 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:11:48 --> Model Class Initialized
DEBUG - 2014-03-06 11:11:48 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
ERROR - 2014-03-06 11:11:48 --> Severity: Notice  --> Undefined index: name C:\wamp\www\nas\application\controllers\register.php 36
DEBUG - 2014-03-06 11:11:48 --> DB Transaction Failure
ERROR - 2014-03-06 11:11:48 --> Query error: Column 'p_adviser' cannot be null
DEBUG - 2014-03-06 11:11:48 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:13:45 --> Config Class Initialized
DEBUG - 2014-03-06 03:13:45 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:13:45 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:13:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:13:45 --> URI Class Initialized
DEBUG - 2014-03-06 03:13:45 --> Router Class Initialized
DEBUG - 2014-03-06 03:13:45 --> Output Class Initialized
DEBUG - 2014-03-06 03:13:45 --> Security Class Initialized
DEBUG - 2014-03-06 03:13:45 --> Input Class Initialized
DEBUG - 2014-03-06 03:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:13:45 --> Language Class Initialized
DEBUG - 2014-03-06 03:13:45 --> Loader Class Initialized
DEBUG - 2014-03-06 03:13:45 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:13:45 --> Session Class Initialized
DEBUG - 2014-03-06 03:13:45 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:13:45 --> Session routines successfully run
DEBUG - 2014-03-06 03:13:45 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:13:45 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:13:45 --> Controller Class Initialized
DEBUG - 2014-03-06 03:13:45 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:13:45 --> Model Class Initialized
DEBUG - 2014-03-06 11:13:46 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
ERROR - 2014-03-06 11:13:46 --> Severity: Notice  --> Undefined index: name C:\wamp\www\nas\application\controllers\register.php 36
DEBUG - 2014-03-06 11:13:46 --> DB Transaction Failure
ERROR - 2014-03-06 11:13:46 --> Query error: Column 'p_adviser' cannot be null
DEBUG - 2014-03-06 11:13:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:15:30 --> Config Class Initialized
DEBUG - 2014-03-06 03:15:30 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:15:30 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:15:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:15:30 --> URI Class Initialized
DEBUG - 2014-03-06 03:15:30 --> Router Class Initialized
DEBUG - 2014-03-06 03:15:30 --> Output Class Initialized
DEBUG - 2014-03-06 03:15:30 --> Security Class Initialized
DEBUG - 2014-03-06 03:15:30 --> Input Class Initialized
DEBUG - 2014-03-06 03:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:15:30 --> Language Class Initialized
DEBUG - 2014-03-06 03:15:30 --> Loader Class Initialized
DEBUG - 2014-03-06 03:15:30 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:15:30 --> Session Class Initialized
DEBUG - 2014-03-06 03:15:30 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:15:30 --> Session routines successfully run
DEBUG - 2014-03-06 03:15:30 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:15:30 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:15:30 --> Controller Class Initialized
DEBUG - 2014-03-06 03:15:30 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:15:30 --> Model Class Initialized
DEBUG - 2014-03-06 11:15:30 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
DEBUG - 2014-03-06 11:15:31 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
ERROR - 2014-03-06 11:15:31 --> Severity: Notice  --> Undefined index: name C:\wamp\www\nas\application\controllers\register.php 37
DEBUG - 2014-03-06 11:15:31 --> DB Transaction Failure
ERROR - 2014-03-06 11:15:31 --> Query error: Column 'p_adviser' cannot be null
DEBUG - 2014-03-06 11:15:31 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:17:23 --> Config Class Initialized
DEBUG - 2014-03-06 03:17:23 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:17:23 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:17:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:17:23 --> URI Class Initialized
DEBUG - 2014-03-06 03:17:23 --> Router Class Initialized
DEBUG - 2014-03-06 03:17:23 --> Output Class Initialized
DEBUG - 2014-03-06 03:17:23 --> Security Class Initialized
DEBUG - 2014-03-06 03:17:23 --> Input Class Initialized
DEBUG - 2014-03-06 03:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:17:23 --> Language Class Initialized
DEBUG - 2014-03-06 03:17:23 --> Loader Class Initialized
DEBUG - 2014-03-06 03:17:23 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:17:23 --> Session Class Initialized
DEBUG - 2014-03-06 03:17:23 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:17:23 --> Session routines successfully run
DEBUG - 2014-03-06 03:17:24 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:17:24 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:17:24 --> Controller Class Initialized
DEBUG - 2014-03-06 03:17:24 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:17:24 --> Model Class Initialized
DEBUG - 2014-03-06 11:17:24 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
DEBUG - 2014-03-06 11:17:24 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
ERROR - 2014-03-06 11:17:24 --> Severity: Notice  --> Undefined index: name C:\wamp\www\nas\application\controllers\register.php 37
DEBUG - 2014-03-06 11:17:24 --> DB Transaction Failure
ERROR - 2014-03-06 11:17:24 --> Query error: Column 'p_adviser' cannot be null
DEBUG - 2014-03-06 11:17:24 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:18:12 --> Config Class Initialized
DEBUG - 2014-03-06 03:18:12 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:18:12 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:18:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:18:12 --> URI Class Initialized
DEBUG - 2014-03-06 03:18:12 --> Router Class Initialized
DEBUG - 2014-03-06 03:18:12 --> Output Class Initialized
DEBUG - 2014-03-06 03:18:12 --> Security Class Initialized
DEBUG - 2014-03-06 03:18:12 --> Input Class Initialized
DEBUG - 2014-03-06 03:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:18:12 --> Language Class Initialized
DEBUG - 2014-03-06 03:18:12 --> Loader Class Initialized
DEBUG - 2014-03-06 03:18:12 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:18:12 --> Session Class Initialized
DEBUG - 2014-03-06 03:18:12 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:18:12 --> Session routines successfully run
DEBUG - 2014-03-06 03:18:12 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:18:12 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:18:12 --> Controller Class Initialized
DEBUG - 2014-03-06 03:18:12 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:18:12 --> Model Class Initialized
DEBUG - 2014-03-06 11:18:12 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
ERROR - 2014-03-06 11:18:12 --> Severity: Notice  --> Undefined index: name C:\wamp\www\nas\application\controllers\register.php 34
DEBUG - 2014-03-06 11:18:12 --> DB Transaction Failure
ERROR - 2014-03-06 11:18:12 --> Query error: Column 'log_message' cannot be null
DEBUG - 2014-03-06 11:18:12 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:19:06 --> Config Class Initialized
DEBUG - 2014-03-06 03:19:06 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:19:06 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:19:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:19:06 --> URI Class Initialized
DEBUG - 2014-03-06 03:19:06 --> Router Class Initialized
DEBUG - 2014-03-06 03:19:06 --> Output Class Initialized
DEBUG - 2014-03-06 03:19:06 --> Security Class Initialized
DEBUG - 2014-03-06 03:19:06 --> Input Class Initialized
DEBUG - 2014-03-06 03:19:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:19:06 --> Language Class Initialized
DEBUG - 2014-03-06 03:19:06 --> Loader Class Initialized
DEBUG - 2014-03-06 03:19:06 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:19:06 --> Session Class Initialized
DEBUG - 2014-03-06 03:19:06 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:19:06 --> Session routines successfully run
DEBUG - 2014-03-06 03:19:06 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:19:06 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:19:06 --> Controller Class Initialized
DEBUG - 2014-03-06 03:19:06 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:19:06 --> Model Class Initialized
DEBUG - 2014-03-06 11:19:06 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
ERROR - 2014-03-06 11:19:07 --> Severity: Notice  --> Undefined index: name C:\wamp\www\nas\application\controllers\register.php 34
DEBUG - 2014-03-06 11:19:07 --> DB Transaction Failure
ERROR - 2014-03-06 11:19:07 --> Query error: Column 'log_message' cannot be null
DEBUG - 2014-03-06 11:19:07 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:20:02 --> Config Class Initialized
DEBUG - 2014-03-06 03:20:02 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:20:02 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:20:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:20:02 --> URI Class Initialized
DEBUG - 2014-03-06 03:20:02 --> Router Class Initialized
DEBUG - 2014-03-06 03:20:02 --> Output Class Initialized
DEBUG - 2014-03-06 03:20:02 --> Security Class Initialized
DEBUG - 2014-03-06 03:20:02 --> Input Class Initialized
DEBUG - 2014-03-06 03:20:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:20:02 --> Language Class Initialized
DEBUG - 2014-03-06 03:20:02 --> Loader Class Initialized
DEBUG - 2014-03-06 03:20:02 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:20:02 --> Session Class Initialized
DEBUG - 2014-03-06 03:20:02 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:20:02 --> Session routines successfully run
DEBUG - 2014-03-06 03:20:02 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:20:02 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:20:02 --> Controller Class Initialized
DEBUG - 2014-03-06 03:20:02 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:20:02 --> Model Class Initialized
DEBUG - 2014-03-06 11:20:02 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
ERROR - 2014-03-06 11:20:02 --> Severity: Notice  --> Undefined index:  C:\wamp\www\nas\application\controllers\register.php 34
DEBUG - 2014-03-06 11:20:03 --> DB Transaction Failure
ERROR - 2014-03-06 11:20:03 --> Query error: Column 'log_message' cannot be null
DEBUG - 2014-03-06 11:20:03 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:20:46 --> Config Class Initialized
DEBUG - 2014-03-06 03:20:46 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:20:46 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:20:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:20:46 --> URI Class Initialized
DEBUG - 2014-03-06 03:20:46 --> Router Class Initialized
DEBUG - 2014-03-06 03:20:46 --> Output Class Initialized
DEBUG - 2014-03-06 03:20:46 --> Security Class Initialized
DEBUG - 2014-03-06 03:20:46 --> Input Class Initialized
DEBUG - 2014-03-06 03:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:20:46 --> Language Class Initialized
DEBUG - 2014-03-06 03:20:46 --> Loader Class Initialized
DEBUG - 2014-03-06 03:20:46 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:20:46 --> Session Class Initialized
DEBUG - 2014-03-06 03:20:46 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:20:47 --> Session routines successfully run
DEBUG - 2014-03-06 03:20:47 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:20:47 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:20:47 --> Controller Class Initialized
DEBUG - 2014-03-06 03:20:47 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:20:47 --> Model Class Initialized
DEBUG - 2014-03-06 11:20:47 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
ERROR - 2014-03-06 11:20:47 --> Severity: Notice  --> Undefined offset: 2 C:\wamp\www\nas\application\controllers\register.php 34
DEBUG - 2014-03-06 11:20:47 --> DB Transaction Failure
ERROR - 2014-03-06 11:20:47 --> Query error: Column 'log_message' cannot be null
DEBUG - 2014-03-06 11:20:47 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:21:20 --> Config Class Initialized
DEBUG - 2014-03-06 03:21:20 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:21:20 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:21:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:21:20 --> URI Class Initialized
DEBUG - 2014-03-06 03:21:20 --> Router Class Initialized
DEBUG - 2014-03-06 03:21:20 --> Output Class Initialized
DEBUG - 2014-03-06 03:21:20 --> Security Class Initialized
DEBUG - 2014-03-06 03:21:20 --> Input Class Initialized
DEBUG - 2014-03-06 03:21:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:21:20 --> Language Class Initialized
DEBUG - 2014-03-06 03:21:20 --> Loader Class Initialized
DEBUG - 2014-03-06 03:21:20 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:21:20 --> Session Class Initialized
DEBUG - 2014-03-06 03:21:20 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:21:20 --> Session routines successfully run
DEBUG - 2014-03-06 03:21:20 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:21:20 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:21:20 --> Controller Class Initialized
DEBUG - 2014-03-06 03:21:20 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:21:20 --> Model Class Initialized
DEBUG - 2014-03-06 11:21:20 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
ERROR - 2014-03-06 11:21:20 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\nas\application\controllers\register.php 34
DEBUG - 2014-03-06 11:21:20 --> DB Transaction Failure
ERROR - 2014-03-06 11:21:20 --> Query error: Column 'log_message' cannot be null
DEBUG - 2014-03-06 11:21:20 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:23:11 --> Config Class Initialized
DEBUG - 2014-03-06 03:23:11 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:23:11 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:23:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:23:11 --> URI Class Initialized
DEBUG - 2014-03-06 03:23:11 --> Router Class Initialized
DEBUG - 2014-03-06 03:23:11 --> Output Class Initialized
DEBUG - 2014-03-06 03:23:11 --> Security Class Initialized
DEBUG - 2014-03-06 03:23:11 --> Input Class Initialized
DEBUG - 2014-03-06 03:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:23:11 --> Language Class Initialized
DEBUG - 2014-03-06 03:23:11 --> Loader Class Initialized
DEBUG - 2014-03-06 03:23:11 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:23:11 --> Session Class Initialized
DEBUG - 2014-03-06 03:23:11 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:23:11 --> Session routines successfully run
DEBUG - 2014-03-06 03:23:11 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:23:11 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:23:11 --> Controller Class Initialized
DEBUG - 2014-03-06 03:23:11 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:23:11 --> Model Class Initialized
DEBUG - 2014-03-06 11:23:11 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
ERROR - 2014-03-06 11:23:11 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\nas\application\controllers\register.php 34
DEBUG - 2014-03-06 11:23:11 --> DB Transaction Failure
ERROR - 2014-03-06 11:23:11 --> Query error: Column 'log_message' cannot be null
DEBUG - 2014-03-06 11:23:12 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:24:19 --> Config Class Initialized
DEBUG - 2014-03-06 03:24:19 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:24:19 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:24:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:24:19 --> URI Class Initialized
DEBUG - 2014-03-06 03:24:19 --> Router Class Initialized
DEBUG - 2014-03-06 03:24:19 --> Output Class Initialized
DEBUG - 2014-03-06 03:24:19 --> Security Class Initialized
DEBUG - 2014-03-06 03:24:19 --> Input Class Initialized
DEBUG - 2014-03-06 03:24:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:24:20 --> Language Class Initialized
DEBUG - 2014-03-06 03:24:20 --> Loader Class Initialized
DEBUG - 2014-03-06 03:24:20 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:24:20 --> Session Class Initialized
DEBUG - 2014-03-06 03:24:20 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:24:20 --> Session routines successfully run
DEBUG - 2014-03-06 03:24:20 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:24:20 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:24:20 --> Controller Class Initialized
DEBUG - 2014-03-06 03:24:20 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:24:20 --> Model Class Initialized
DEBUG - 2014-03-06 11:24:20 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
ERROR - 2014-03-06 11:24:20 --> Severity: Notice  --> Undefined index: name C:\wamp\www\nas\application\controllers\register.php 34
DEBUG - 2014-03-06 11:24:20 --> DB Transaction Failure
ERROR - 2014-03-06 11:24:20 --> Query error: Column 'log_message' cannot be null
DEBUG - 2014-03-06 11:24:20 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:26:52 --> Config Class Initialized
DEBUG - 2014-03-06 03:26:52 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:26:52 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:26:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:26:52 --> URI Class Initialized
DEBUG - 2014-03-06 03:26:52 --> Router Class Initialized
DEBUG - 2014-03-06 03:26:52 --> Output Class Initialized
DEBUG - 2014-03-06 03:26:52 --> Security Class Initialized
DEBUG - 2014-03-06 03:26:52 --> Input Class Initialized
DEBUG - 2014-03-06 03:26:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:26:52 --> Language Class Initialized
DEBUG - 2014-03-06 03:26:52 --> Loader Class Initialized
DEBUG - 2014-03-06 03:26:52 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:26:52 --> Session Class Initialized
DEBUG - 2014-03-06 03:26:52 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:26:52 --> Session routines successfully run
DEBUG - 2014-03-06 03:26:52 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:26:52 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:26:52 --> Controller Class Initialized
DEBUG - 2014-03-06 03:26:52 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:26:52 --> Model Class Initialized
DEBUG - 2014-03-06 11:26:52 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
DEBUG - 2014-03-06 11:26:53 --> array
ERROR - 2014-03-06 11:26:53 --> Severity: Notice  --> Undefined index: name C:\wamp\www\nas\application\controllers\register.php 37
DEBUG - 2014-03-06 11:26:53 --> DB Transaction Failure
ERROR - 2014-03-06 11:26:53 --> Query error: Column 'p_adviser' cannot be null
DEBUG - 2014-03-06 11:26:53 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:31:13 --> Config Class Initialized
DEBUG - 2014-03-06 03:31:13 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:31:13 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:31:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:31:13 --> URI Class Initialized
DEBUG - 2014-03-06 03:31:13 --> Router Class Initialized
DEBUG - 2014-03-06 03:31:13 --> Output Class Initialized
DEBUG - 2014-03-06 03:31:13 --> Security Class Initialized
DEBUG - 2014-03-06 03:31:13 --> Input Class Initialized
DEBUG - 2014-03-06 03:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:31:13 --> Language Class Initialized
DEBUG - 2014-03-06 03:31:13 --> Loader Class Initialized
DEBUG - 2014-03-06 03:31:13 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:31:13 --> Session Class Initialized
DEBUG - 2014-03-06 03:31:13 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:31:13 --> Session routines successfully run
DEBUG - 2014-03-06 03:31:13 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:31:13 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:31:13 --> Controller Class Initialized
DEBUG - 2014-03-06 03:31:13 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:31:13 --> Model Class Initialized
DEBUG - 2014-03-06 11:31:13 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
ERROR - 2014-03-06 11:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\nas\application\controllers\register.php 34
DEBUG - 2014-03-06 11:31:14 --> NULL
ERROR - 2014-03-06 11:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\nas\application\controllers\register.php 37
DEBUG - 2014-03-06 11:31:14 --> DB Transaction Failure
ERROR - 2014-03-06 11:31:14 --> Query error: Column 'p_adviser' cannot be null
DEBUG - 2014-03-06 11:31:14 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:32:01 --> Config Class Initialized
DEBUG - 2014-03-06 03:32:01 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:32:01 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:32:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:32:01 --> URI Class Initialized
DEBUG - 2014-03-06 03:32:01 --> Router Class Initialized
DEBUG - 2014-03-06 03:32:01 --> Output Class Initialized
DEBUG - 2014-03-06 03:32:01 --> Security Class Initialized
DEBUG - 2014-03-06 03:32:01 --> Input Class Initialized
DEBUG - 2014-03-06 03:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:32:02 --> Language Class Initialized
DEBUG - 2014-03-06 03:32:02 --> Loader Class Initialized
DEBUG - 2014-03-06 03:32:02 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:32:02 --> Session Class Initialized
DEBUG - 2014-03-06 03:32:02 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:32:02 --> Session routines successfully run
DEBUG - 2014-03-06 03:32:02 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:32:02 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:32:02 --> Controller Class Initialized
DEBUG - 2014-03-06 03:32:02 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:32:02 --> Model Class Initialized
DEBUG - 2014-03-06 11:32:02 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
DEBUG - 2014-03-06 11:32:02 --> array
ERROR - 2014-03-06 11:32:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\nas\application\controllers\register.php 37
DEBUG - 2014-03-06 11:32:02 --> DB Transaction Failure
ERROR - 2014-03-06 11:32:02 --> Query error: Column 'p_adviser' cannot be null
DEBUG - 2014-03-06 11:32:02 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:32:51 --> Config Class Initialized
DEBUG - 2014-03-06 03:32:51 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:32:51 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:32:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:32:51 --> URI Class Initialized
DEBUG - 2014-03-06 03:32:51 --> Router Class Initialized
DEBUG - 2014-03-06 03:32:51 --> Output Class Initialized
DEBUG - 2014-03-06 03:32:51 --> Security Class Initialized
DEBUG - 2014-03-06 03:32:51 --> Input Class Initialized
DEBUG - 2014-03-06 03:32:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:32:51 --> Language Class Initialized
DEBUG - 2014-03-06 03:32:51 --> Loader Class Initialized
DEBUG - 2014-03-06 03:32:51 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:32:51 --> Session Class Initialized
DEBUG - 2014-03-06 03:32:51 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:32:51 --> Session routines successfully run
DEBUG - 2014-03-06 03:32:51 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:32:51 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:32:51 --> Controller Class Initialized
DEBUG - 2014-03-06 03:32:51 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:32:51 --> Model Class Initialized
DEBUG - 2014-03-06 11:32:51 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
DEBUG - 2014-03-06 11:32:52 --> array
ERROR - 2014-03-06 11:32:52 --> Severity: Notice  --> Undefined index: name C:\wamp\www\nas\application\controllers\register.php 37
DEBUG - 2014-03-06 11:32:52 --> DB Transaction Failure
ERROR - 2014-03-06 11:32:52 --> Query error: Column 'p_adviser' cannot be null
DEBUG - 2014-03-06 11:32:52 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:34:40 --> Config Class Initialized
DEBUG - 2014-03-06 03:34:40 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:34:40 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:34:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:34:40 --> URI Class Initialized
DEBUG - 2014-03-06 03:34:40 --> Router Class Initialized
DEBUG - 2014-03-06 03:34:40 --> Output Class Initialized
DEBUG - 2014-03-06 03:34:40 --> Security Class Initialized
DEBUG - 2014-03-06 03:34:40 --> Input Class Initialized
DEBUG - 2014-03-06 03:34:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:34:40 --> Language Class Initialized
DEBUG - 2014-03-06 03:34:41 --> Loader Class Initialized
DEBUG - 2014-03-06 03:34:41 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:34:41 --> Session Class Initialized
DEBUG - 2014-03-06 03:34:41 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:34:41 --> Session routines successfully run
DEBUG - 2014-03-06 03:34:41 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:34:41 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:34:41 --> Controller Class Initialized
DEBUG - 2014-03-06 03:34:41 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:34:41 --> Model Class Initialized
DEBUG - 2014-03-06 11:34:41 --> [{"id":"5","n":"\u8449\u671f\u8ca1"}]
DEBUG - 2014-03-06 11:34:41 --> array
ERROR - 2014-03-06 11:34:41 --> Severity: Notice  --> Undefined index: n C:\wamp\www\nas\application\controllers\register.php 37
DEBUG - 2014-03-06 11:34:41 --> DB Transaction Failure
ERROR - 2014-03-06 11:34:41 --> Query error: Column 'p_adviser' cannot be null
DEBUG - 2014-03-06 11:34:41 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:35:44 --> Config Class Initialized
DEBUG - 2014-03-06 03:35:44 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:35:44 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:35:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:35:45 --> URI Class Initialized
DEBUG - 2014-03-06 03:35:45 --> Router Class Initialized
DEBUG - 2014-03-06 03:35:45 --> Output Class Initialized
DEBUG - 2014-03-06 03:35:45 --> Security Class Initialized
DEBUG - 2014-03-06 03:35:45 --> Input Class Initialized
DEBUG - 2014-03-06 03:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:35:45 --> Language Class Initialized
DEBUG - 2014-03-06 03:35:45 --> Loader Class Initialized
DEBUG - 2014-03-06 03:35:45 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:35:45 --> Session Class Initialized
DEBUG - 2014-03-06 03:35:45 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:35:45 --> Session routines successfully run
DEBUG - 2014-03-06 03:35:45 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:35:45 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:35:45 --> Controller Class Initialized
DEBUG - 2014-03-06 03:35:45 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:35:45 --> Model Class Initialized
DEBUG - 2014-03-06 11:35:45 --> [{"id":"5","n":"\u8449\u671f\u8ca1"}]
ERROR - 2014-03-06 11:35:45 --> Severity: Notice  --> Undefined index: n C:\wamp\www\nas\application\controllers\register.php 34
DEBUG - 2014-03-06 11:35:45 --> DB Transaction Failure
ERROR - 2014-03-06 11:35:45 --> Query error: Column 'log_message' cannot be null
DEBUG - 2014-03-06 11:35:45 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:38:30 --> Config Class Initialized
DEBUG - 2014-03-06 03:38:30 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:38:30 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:38:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:38:30 --> URI Class Initialized
DEBUG - 2014-03-06 03:38:30 --> Router Class Initialized
DEBUG - 2014-03-06 03:38:30 --> Output Class Initialized
DEBUG - 2014-03-06 03:38:30 --> Security Class Initialized
DEBUG - 2014-03-06 03:38:30 --> Input Class Initialized
DEBUG - 2014-03-06 03:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:38:30 --> Language Class Initialized
DEBUG - 2014-03-06 03:38:30 --> Loader Class Initialized
DEBUG - 2014-03-06 03:38:30 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:38:30 --> Session Class Initialized
DEBUG - 2014-03-06 03:38:30 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:38:30 --> Session routines successfully run
DEBUG - 2014-03-06 03:38:30 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:38:30 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:38:30 --> Controller Class Initialized
DEBUG - 2014-03-06 03:38:30 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:38:30 --> Model Class Initialized
DEBUG - 2014-03-06 11:38:30 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
ERROR - 2014-03-06 11:38:31 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\nas\system\database\drivers\mysql\mysql_driver.php 553
DEBUG - 2014-03-06 11:38:31 --> DB Transaction Failure
ERROR - 2014-03-06 11:38:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' 0, '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML,' at line 1
DEBUG - 2014-03-06 11:38:31 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:39:46 --> Config Class Initialized
DEBUG - 2014-03-06 03:39:46 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:39:46 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:39:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:39:46 --> URI Class Initialized
DEBUG - 2014-03-06 03:39:46 --> Router Class Initialized
DEBUG - 2014-03-06 03:39:46 --> Output Class Initialized
DEBUG - 2014-03-06 03:39:46 --> Security Class Initialized
DEBUG - 2014-03-06 03:39:46 --> Input Class Initialized
DEBUG - 2014-03-06 03:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:39:46 --> Language Class Initialized
DEBUG - 2014-03-06 03:39:46 --> Loader Class Initialized
DEBUG - 2014-03-06 03:39:46 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:39:46 --> Session Class Initialized
DEBUG - 2014-03-06 03:39:46 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:39:46 --> Session routines successfully run
DEBUG - 2014-03-06 03:39:46 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:39:46 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:39:46 --> Controller Class Initialized
DEBUG - 2014-03-06 03:39:46 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:39:46 --> Model Class Initialized
DEBUG - 2014-03-06 11:39:46 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
ERROR - 2014-03-06 11:39:46 --> Severity: Notice  --> Array to string conversion C:\wamp\www\nas\system\database\drivers\mysql\mysql_driver.php 553
DEBUG - 2014-03-06 11:39:46 --> DB Transaction Failure
ERROR - 2014-03-06 11:39:46 --> Query error: Unknown column 'Array' in 'field list'
DEBUG - 2014-03-06 11:39:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:45:37 --> Config Class Initialized
DEBUG - 2014-03-06 03:45:37 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:45:37 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:45:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:45:37 --> URI Class Initialized
DEBUG - 2014-03-06 03:45:37 --> Router Class Initialized
DEBUG - 2014-03-06 03:45:37 --> Output Class Initialized
DEBUG - 2014-03-06 03:45:37 --> Security Class Initialized
DEBUG - 2014-03-06 03:45:37 --> Input Class Initialized
DEBUG - 2014-03-06 03:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:45:37 --> Language Class Initialized
DEBUG - 2014-03-06 03:45:37 --> Loader Class Initialized
DEBUG - 2014-03-06 03:45:37 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:45:37 --> Session Class Initialized
DEBUG - 2014-03-06 03:45:37 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:45:37 --> Session routines successfully run
DEBUG - 2014-03-06 03:45:37 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:45:37 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:45:37 --> Controller Class Initialized
DEBUG - 2014-03-06 03:45:37 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:45:37 --> Model Class Initialized
DEBUG - 2014-03-06 11:45:37 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
DEBUG - 2014-03-06 11:45:38 --> 葉期財
DEBUG - 2014-03-06 11:45:38 --> DB Transaction Failure
ERROR - 2014-03-06 11:45:38 --> Query error: Unknown column 'Array' in 'field list'
DEBUG - 2014-03-06 11:45:38 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:46:35 --> Config Class Initialized
DEBUG - 2014-03-06 03:46:35 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:46:35 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:46:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:46:35 --> URI Class Initialized
DEBUG - 2014-03-06 03:46:35 --> Router Class Initialized
DEBUG - 2014-03-06 03:46:35 --> Output Class Initialized
DEBUG - 2014-03-06 03:46:35 --> Security Class Initialized
DEBUG - 2014-03-06 03:46:35 --> Input Class Initialized
DEBUG - 2014-03-06 03:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:46:35 --> Language Class Initialized
DEBUG - 2014-03-06 03:46:35 --> Loader Class Initialized
DEBUG - 2014-03-06 03:46:35 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:46:35 --> Session Class Initialized
DEBUG - 2014-03-06 03:46:35 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:46:35 --> Session routines successfully run
DEBUG - 2014-03-06 03:46:35 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:46:35 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:46:35 --> Controller Class Initialized
DEBUG - 2014-03-06 03:46:35 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:46:35 --> Model Class Initialized
DEBUG - 2014-03-06 11:46:36 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
DEBUG - 2014-03-06 11:46:36 --> 葉期財
ERROR - 2014-03-06 11:46:36 --> Severity: Notice  --> Undefined variable: str C:\wamp\www\nas\application\models\project_model.php 21
ERROR - 2014-03-06 11:46:36 --> Invalid query: 
DEBUG - 2014-03-06 11:46:36 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:48:04 --> Config Class Initialized
DEBUG - 2014-03-06 03:48:04 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:48:04 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:48:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:48:04 --> URI Class Initialized
DEBUG - 2014-03-06 03:48:04 --> Router Class Initialized
DEBUG - 2014-03-06 03:48:04 --> Output Class Initialized
DEBUG - 2014-03-06 03:48:04 --> Security Class Initialized
DEBUG - 2014-03-06 03:48:04 --> Input Class Initialized
DEBUG - 2014-03-06 03:48:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:48:04 --> Language Class Initialized
DEBUG - 2014-03-06 03:48:04 --> Loader Class Initialized
DEBUG - 2014-03-06 03:48:04 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:48:04 --> Session Class Initialized
DEBUG - 2014-03-06 03:48:04 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:48:04 --> Session routines successfully run
DEBUG - 2014-03-06 03:48:04 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:48:04 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:48:04 --> Controller Class Initialized
DEBUG - 2014-03-06 03:48:04 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:48:05 --> Model Class Initialized
DEBUG - 2014-03-06 11:48:05 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
DEBUG - 2014-03-06 11:48:05 --> 葉期財
ERROR - 2014-03-06 11:48:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\nas\application\controllers\register.php 56
DEBUG - 2014-03-06 11:48:05 --> DB Transaction Failure
ERROR - 2014-03-06 11:48:05 --> Query error: Column 's_project' cannot be null
DEBUG - 2014-03-06 11:48:05 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:51:12 --> Config Class Initialized
DEBUG - 2014-03-06 03:51:12 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:51:12 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:51:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:51:12 --> URI Class Initialized
DEBUG - 2014-03-06 03:51:12 --> Router Class Initialized
DEBUG - 2014-03-06 03:51:12 --> Output Class Initialized
DEBUG - 2014-03-06 03:51:12 --> Security Class Initialized
DEBUG - 2014-03-06 03:51:12 --> Input Class Initialized
DEBUG - 2014-03-06 03:51:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:51:12 --> Language Class Initialized
DEBUG - 2014-03-06 03:51:12 --> Loader Class Initialized
DEBUG - 2014-03-06 03:51:12 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:51:12 --> Session Class Initialized
DEBUG - 2014-03-06 03:51:12 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:51:12 --> Session routines successfully run
DEBUG - 2014-03-06 03:51:12 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:51:12 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:51:12 --> Controller Class Initialized
DEBUG - 2014-03-06 03:51:12 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:51:12 --> Model Class Initialized
DEBUG - 2014-03-06 11:51:13 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
DEBUG - 2014-03-06 11:51:13 --> 葉期財
ERROR - 2014-03-06 11:51:13 --> Severity: Notice  --> Undefined index: p_id C:\wamp\www\nas\application\controllers\register.php 56
DEBUG - 2014-03-06 11:51:13 --> DB Transaction Failure
ERROR - 2014-03-06 11:51:13 --> Query error: Column 's_project' cannot be null
DEBUG - 2014-03-06 11:51:13 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:52:18 --> Config Class Initialized
DEBUG - 2014-03-06 03:52:18 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:52:18 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:52:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:52:18 --> URI Class Initialized
DEBUG - 2014-03-06 03:52:18 --> Router Class Initialized
DEBUG - 2014-03-06 03:52:18 --> Output Class Initialized
DEBUG - 2014-03-06 03:52:18 --> Security Class Initialized
DEBUG - 2014-03-06 03:52:18 --> Input Class Initialized
DEBUG - 2014-03-06 03:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:52:18 --> Language Class Initialized
DEBUG - 2014-03-06 03:52:18 --> Loader Class Initialized
DEBUG - 2014-03-06 03:52:18 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:52:18 --> Session Class Initialized
DEBUG - 2014-03-06 03:52:18 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:52:18 --> Session routines successfully run
DEBUG - 2014-03-06 03:52:18 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:52:18 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:52:18 --> Controller Class Initialized
DEBUG - 2014-03-06 03:52:18 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:52:18 --> Model Class Initialized
DEBUG - 2014-03-06 11:52:18 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
DEBUG - 2014-03-06 11:52:18 --> 葉期財
ERROR - 2014-03-06 11:52:19 --> Severity: Notice  --> Undefined index: p_id C:\wamp\www\nas\application\controllers\register.php 56
DEBUG - 2014-03-06 11:52:19 --> DB Transaction Failure
ERROR - 2014-03-06 11:52:19 --> Query error: Column 's_project' cannot be null
DEBUG - 2014-03-06 11:52:19 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:53:10 --> Config Class Initialized
DEBUG - 2014-03-06 03:53:10 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:53:10 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:53:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:53:10 --> URI Class Initialized
DEBUG - 2014-03-06 03:53:10 --> Router Class Initialized
DEBUG - 2014-03-06 03:53:10 --> Output Class Initialized
DEBUG - 2014-03-06 03:53:10 --> Security Class Initialized
DEBUG - 2014-03-06 03:53:10 --> Input Class Initialized
DEBUG - 2014-03-06 03:53:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:53:10 --> Language Class Initialized
DEBUG - 2014-03-06 03:53:10 --> Loader Class Initialized
DEBUG - 2014-03-06 03:53:10 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:53:11 --> Session Class Initialized
DEBUG - 2014-03-06 03:53:11 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:53:11 --> Session routines successfully run
DEBUG - 2014-03-06 03:53:11 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:53:11 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:53:11 --> Controller Class Initialized
DEBUG - 2014-03-06 03:53:11 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:53:11 --> Model Class Initialized
DEBUG - 2014-03-06 11:53:11 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
DEBUG - 2014-03-06 11:53:11 --> 葉期財
DEBUG - 2014-03-06 11:53:11 --> [{"max(p_id)":"206"}]
ERROR - 2014-03-06 11:53:11 --> Severity: Notice  --> Undefined index: p_id C:\wamp\www\nas\application\controllers\register.php 56
DEBUG - 2014-03-06 11:53:11 --> DB Transaction Failure
ERROR - 2014-03-06 11:53:12 --> Query error: Column 's_project' cannot be null
DEBUG - 2014-03-06 11:53:12 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-06 03:54:20 --> Config Class Initialized
DEBUG - 2014-03-06 03:54:20 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:54:20 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:54:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:54:20 --> URI Class Initialized
DEBUG - 2014-03-06 03:54:20 --> Router Class Initialized
DEBUG - 2014-03-06 03:54:20 --> Output Class Initialized
DEBUG - 2014-03-06 03:54:20 --> Security Class Initialized
DEBUG - 2014-03-06 03:54:20 --> Input Class Initialized
DEBUG - 2014-03-06 03:54:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:54:20 --> Language Class Initialized
DEBUG - 2014-03-06 03:54:20 --> Loader Class Initialized
DEBUG - 2014-03-06 03:54:20 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:54:20 --> Session Class Initialized
DEBUG - 2014-03-06 03:54:20 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:54:20 --> Session routines successfully run
DEBUG - 2014-03-06 03:54:20 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:54:20 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:54:20 --> Controller Class Initialized
DEBUG - 2014-03-06 03:54:20 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:54:20 --> Model Class Initialized
DEBUG - 2014-03-06 11:54:20 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
DEBUG - 2014-03-06 11:54:20 --> 葉期財
DEBUG - 2014-03-06 11:54:20 --> [{"p_id":"207"}]
ERROR - 2014-03-06 11:54:20 --> Severity: Notice  --> Undefined property: Register::$keyword_model C:\wamp\www\nas\application\controllers\register.php 68
DEBUG - 2014-03-06 03:55:21 --> Config Class Initialized
DEBUG - 2014-03-06 03:55:21 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:55:21 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:55:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:55:21 --> URI Class Initialized
DEBUG - 2014-03-06 03:55:21 --> Router Class Initialized
DEBUG - 2014-03-06 03:55:21 --> Output Class Initialized
DEBUG - 2014-03-06 03:55:21 --> Security Class Initialized
DEBUG - 2014-03-06 03:55:21 --> Input Class Initialized
DEBUG - 2014-03-06 03:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:55:21 --> Language Class Initialized
DEBUG - 2014-03-06 03:55:21 --> Loader Class Initialized
DEBUG - 2014-03-06 03:55:21 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:55:21 --> Session Class Initialized
DEBUG - 2014-03-06 03:55:21 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:55:21 --> Session routines successfully run
DEBUG - 2014-03-06 03:55:21 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:55:21 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:55:21 --> Controller Class Initialized
DEBUG - 2014-03-06 03:55:21 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:55:21 --> this->setMessage()
DEBUG - 2014-03-06 11:55:21 --> File loaded: application/views/register.php
DEBUG - 2014-03-06 11:55:21 --> File loaded: application/views/master.php
DEBUG - 2014-03-06 11:55:21 --> Final output sent to browser
DEBUG - 2014-03-06 11:55:21 --> Total execution time: 0.3488
DEBUG - 2014-03-06 03:55:21 --> Config Class Initialized
DEBUG - 2014-03-06 03:55:21 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:55:21 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:55:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:55:22 --> URI Class Initialized
DEBUG - 2014-03-06 03:55:22 --> Router Class Initialized
DEBUG - 2014-03-06 03:55:22 --> Output Class Initialized
DEBUG - 2014-03-06 03:55:22 --> Security Class Initialized
DEBUG - 2014-03-06 03:55:22 --> Input Class Initialized
DEBUG - 2014-03-06 03:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:55:22 --> Language Class Initialized
DEBUG - 2014-03-06 03:55:22 --> Loader Class Initialized
DEBUG - 2014-03-06 03:55:22 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:55:22 --> Session Class Initialized
DEBUG - 2014-03-06 03:55:22 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:55:22 --> Session routines successfully run
DEBUG - 2014-03-06 03:55:22 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:55:22 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:55:22 --> Controller Class Initialized
DEBUG - 2014-03-06 03:55:22 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:55:22 --> Model Class Initialized
DEBUG - 2014-03-06 11:55:22 --> [{"id":"1","name":"\u738b\u8cb4\u6c11"},{"id":"2","name":"\u5f35\u5609\u9298"},{"id":"3","name":"\u6d2a\u6e05\u6587"},{"id":"4","name":"\u9673\u4ec1\u7965"},{"id":"5","name":"\u8449\u671f\u8ca1"},{"id":"6","name":"\u9805\u52e4\u6821"},{"id":"7","name":"\u5f35\u826f\u653f"},{"id":"8","name":"\u97d3\u6167\u6797"},{"id":"9","name":"\u7f85\u5efa\u9298"},{"id":"10","name":"\u6881\u514b\u65b0"},{"id":"11","name":"\u6d2a\u570b\u8208"}]
DEBUG - 2014-03-06 11:55:22 --> Final output sent to browser
DEBUG - 2014-03-06 11:55:22 --> Total execution time: 0.6910
DEBUG - 2014-03-06 03:58:34 --> Config Class Initialized
DEBUG - 2014-03-06 03:58:34 --> Hooks Class Initialized
DEBUG - 2014-03-06 03:58:34 --> Utf8 Class Initialized
DEBUG - 2014-03-06 03:58:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 03:58:34 --> URI Class Initialized
DEBUG - 2014-03-06 03:58:34 --> Router Class Initialized
DEBUG - 2014-03-06 03:58:34 --> Output Class Initialized
DEBUG - 2014-03-06 03:58:34 --> Security Class Initialized
DEBUG - 2014-03-06 03:58:34 --> Input Class Initialized
DEBUG - 2014-03-06 03:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 03:58:34 --> Language Class Initialized
DEBUG - 2014-03-06 03:58:34 --> Loader Class Initialized
DEBUG - 2014-03-06 03:58:35 --> Database Driver Class Initialized
DEBUG - 2014-03-06 03:58:35 --> Session Class Initialized
DEBUG - 2014-03-06 03:58:35 --> Helper loaded: string_helper
DEBUG - 2014-03-06 03:58:35 --> Session routines successfully run
DEBUG - 2014-03-06 03:58:35 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 03:58:35 --> User Agent Class Initialized
DEBUG - 2014-03-06 03:58:35 --> Controller Class Initialized
DEBUG - 2014-03-06 03:58:35 --> Helper loaded: url_helper
DEBUG - 2014-03-06 03:58:35 --> Model Class Initialized
DEBUG - 2014-03-06 11:58:35 --> [{"id":"5","name":"\u8449\u671f\u8ca1"}]
DEBUG - 2014-03-06 11:58:35 --> 葉期財
DEBUG - 2014-03-06 11:58:35 --> [{"p_id":"208"}]
ERROR - 2014-03-06 11:58:35 --> Severity: Warning  --> mkdir(): No such file or directory C:\wamp\www\nas\application\controllers\register.php 73
ERROR - 2014-03-06 11:58:35 --> Severity: Warning  --> fopen(/nas/project/A0128310/index.txt): failed to open stream: No such file or directory C:\wamp\www\nas\application\controllers\register.php 75
ERROR - 2014-03-06 11:58:35 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given C:\wamp\www\nas\application\controllers\register.php 77
ERROR - 2014-03-06 11:58:35 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\wamp\www\nas\application\controllers\register.php 78
DEBUG - 2014-03-06 11:58:35 --> Final output sent to browser
DEBUG - 2014-03-06 11:58:35 --> Total execution time: 0.9981
DEBUG - 2014-03-06 04:00:21 --> Config Class Initialized
DEBUG - 2014-03-06 04:00:21 --> Hooks Class Initialized
DEBUG - 2014-03-06 04:00:21 --> Utf8 Class Initialized
DEBUG - 2014-03-06 04:00:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 04:00:21 --> URI Class Initialized
DEBUG - 2014-03-06 04:00:21 --> Router Class Initialized
DEBUG - 2014-03-06 04:00:21 --> Output Class Initialized
DEBUG - 2014-03-06 04:00:21 --> Security Class Initialized
DEBUG - 2014-03-06 04:00:21 --> Input Class Initialized
DEBUG - 2014-03-06 04:00:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 04:00:21 --> Language Class Initialized
DEBUG - 2014-03-06 04:00:21 --> Loader Class Initialized
DEBUG - 2014-03-06 04:00:21 --> Database Driver Class Initialized
DEBUG - 2014-03-06 04:00:21 --> Session Class Initialized
DEBUG - 2014-03-06 04:00:21 --> Helper loaded: string_helper
DEBUG - 2014-03-06 04:00:21 --> Session routines successfully run
DEBUG - 2014-03-06 04:00:21 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 04:00:21 --> User Agent Class Initialized
DEBUG - 2014-03-06 04:00:21 --> Controller Class Initialized
DEBUG - 2014-03-06 04:00:21 --> Helper loaded: url_helper
DEBUG - 2014-03-06 04:00:21 --> this->setMessage()
DEBUG - 2014-03-06 12:00:21 --> File loaded: application/views/register.php
DEBUG - 2014-03-06 12:00:21 --> File loaded: application/views/master.php
DEBUG - 2014-03-06 12:00:21 --> Final output sent to browser
DEBUG - 2014-03-06 12:00:21 --> Total execution time: 0.4218
DEBUG - 2014-03-06 04:00:21 --> Config Class Initialized
DEBUG - 2014-03-06 04:00:21 --> Hooks Class Initialized
DEBUG - 2014-03-06 04:00:21 --> Utf8 Class Initialized
DEBUG - 2014-03-06 04:00:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-06 04:00:21 --> URI Class Initialized
DEBUG - 2014-03-06 04:00:21 --> Router Class Initialized
DEBUG - 2014-03-06 04:00:21 --> Output Class Initialized
DEBUG - 2014-03-06 04:00:21 --> Security Class Initialized
DEBUG - 2014-03-06 04:00:22 --> Input Class Initialized
DEBUG - 2014-03-06 04:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-06 04:00:22 --> Language Class Initialized
DEBUG - 2014-03-06 04:00:22 --> Loader Class Initialized
DEBUG - 2014-03-06 04:00:22 --> Database Driver Class Initialized
DEBUG - 2014-03-06 04:00:22 --> Session Class Initialized
DEBUG - 2014-03-06 04:00:22 --> Helper loaded: string_helper
DEBUG - 2014-03-06 04:00:22 --> Session routines successfully run
DEBUG - 2014-03-06 04:00:22 --> XML-RPC Class Initialized
DEBUG - 2014-03-06 04:00:22 --> User Agent Class Initialized
DEBUG - 2014-03-06 04:00:22 --> Controller Class Initialized
DEBUG - 2014-03-06 04:00:22 --> Helper loaded: url_helper
DEBUG - 2014-03-06 04:00:22 --> Model Class Initialized
DEBUG - 2014-03-06 12:00:22 --> [{"id":"1","name":"\u738b\u8cb4\u6c11"},{"id":"2","name":"\u5f35\u5609\u9298"},{"id":"3","name":"\u6d2a\u6e05\u6587"},{"id":"4","name":"\u9673\u4ec1\u7965"},{"id":"5","name":"\u8449\u671f\u8ca1"},{"id":"6","name":"\u9805\u52e4\u6821"},{"id":"7","name":"\u5f35\u826f\u653f"},{"id":"8","name":"\u97d3\u6167\u6797"},{"id":"9","name":"\u7f85\u5efa\u9298"},{"id":"10","name":"\u6881\u514b\u65b0"},{"id":"11","name":"\u6d2a\u570b\u8208"}]
DEBUG - 2014-03-06 12:00:22 --> Final output sent to browser
DEBUG - 2014-03-06 12:00:22 --> Total execution time: 0.7048
