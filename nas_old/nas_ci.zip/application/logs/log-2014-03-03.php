<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-03-03 01:20:14 --> Config Class Initialized
DEBUG - 2014-03-03 01:20:14 --> Hooks Class Initialized
DEBUG - 2014-03-03 01:20:14 --> Utf8 Class Initialized
DEBUG - 2014-03-03 01:20:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-03 01:20:14 --> URI Class Initialized
DEBUG - 2014-03-03 01:20:14 --> Router Class Initialized
DEBUG - 2014-03-03 01:20:14 --> Output Class Initialized
DEBUG - 2014-03-03 01:20:14 --> Security Class Initialized
DEBUG - 2014-03-03 01:20:14 --> Input Class Initialized
DEBUG - 2014-03-03 01:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-03 01:20:14 --> Language Class Initialized
DEBUG - 2014-03-03 01:20:14 --> Loader Class Initialized
DEBUG - 2014-03-03 01:20:14 --> Database Driver Class Initialized
ERROR - 2014-03-03 01:20:14 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\apps\career\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-03-03 01:20:15 --> Session Class Initialized
DEBUG - 2014-03-03 01:20:15 --> Helper loaded: string_helper
DEBUG - 2014-03-03 01:20:15 --> A session cookie was not found.
DEBUG - 2014-03-03 01:20:15 --> Session routines successfully run
DEBUG - 2014-03-03 01:20:15 --> XML-RPC Class Initialized
DEBUG - 2014-03-03 01:20:15 --> User Agent Class Initialized
DEBUG - 2014-03-03 01:20:15 --> Controller Class Initialized
DEBUG - 2014-03-03 01:20:15 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-03-03 01:20:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-03-03 01:20:20 --> Config Class Initialized
DEBUG - 2014-03-03 01:20:20 --> Hooks Class Initialized
DEBUG - 2014-03-03 01:20:20 --> Utf8 Class Initialized
DEBUG - 2014-03-03 01:20:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-03 01:20:20 --> URI Class Initialized
DEBUG - 2014-03-03 01:20:20 --> Router Class Initialized
DEBUG - 2014-03-03 01:20:20 --> No URI present. Default controller set.
DEBUG - 2014-03-03 01:20:20 --> Output Class Initialized
DEBUG - 2014-03-03 01:20:20 --> Security Class Initialized
DEBUG - 2014-03-03 01:20:20 --> Input Class Initialized
DEBUG - 2014-03-03 01:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-03 01:20:20 --> Language Class Initialized
DEBUG - 2014-03-03 01:20:20 --> Loader Class Initialized
DEBUG - 2014-03-03 01:20:20 --> Database Driver Class Initialized
DEBUG - 2014-03-03 01:20:20 --> Session Class Initialized
DEBUG - 2014-03-03 01:20:20 --> Helper loaded: string_helper
DEBUG - 2014-03-03 01:20:20 --> Session routines successfully run
DEBUG - 2014-03-03 01:20:20 --> XML-RPC Class Initialized
DEBUG - 2014-03-03 01:20:20 --> User Agent Class Initialized
DEBUG - 2014-03-03 01:20:20 --> Controller Class Initialized
DEBUG - 2014-03-03 01:20:20 --> Helper loaded: url_helper
DEBUG - 2014-03-03 01:20:20 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-03-03 01:20:20 --> this->setMessage()
DEBUG - 2014-03-03 01:20:20 --> Model Class Initialized
DEBUG - 2014-03-03 01:20:20 --> this->setMessage()
DEBUG - 2014-03-03 01:20:20 --> File loaded: application/views/login.php
DEBUG - 2014-03-03 01:20:20 --> Final output sent to browser
DEBUG - 2014-03-03 01:20:20 --> Total execution time: 0.5533
DEBUG - 2014-03-03 01:20:38 --> Config Class Initialized
DEBUG - 2014-03-03 01:20:38 --> Hooks Class Initialized
DEBUG - 2014-03-03 01:20:38 --> Utf8 Class Initialized
DEBUG - 2014-03-03 01:20:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-03 01:20:38 --> URI Class Initialized
DEBUG - 2014-03-03 01:20:38 --> Router Class Initialized
DEBUG - 2014-03-03 01:20:38 --> Output Class Initialized
DEBUG - 2014-03-03 01:20:38 --> Security Class Initialized
DEBUG - 2014-03-03 01:20:38 --> Input Class Initialized
DEBUG - 2014-03-03 01:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-03 01:20:38 --> Language Class Initialized
DEBUG - 2014-03-03 01:20:38 --> Loader Class Initialized
DEBUG - 2014-03-03 01:20:38 --> Database Driver Class Initialized
ERROR - 2014-03-03 01:20:38 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\apps\career\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-03-03 01:20:39 --> Session Class Initialized
DEBUG - 2014-03-03 01:20:39 --> Helper loaded: string_helper
DEBUG - 2014-03-03 01:20:39 --> Session routines successfully run
DEBUG - 2014-03-03 01:20:39 --> XML-RPC Class Initialized
DEBUG - 2014-03-03 01:20:39 --> User Agent Class Initialized
DEBUG - 2014-03-03 01:20:39 --> Controller Class Initialized
DEBUG - 2014-03-03 01:20:39 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-03-03 01:20:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-03-03 01:23:22 --> Config Class Initialized
DEBUG - 2014-03-03 01:23:22 --> Hooks Class Initialized
DEBUG - 2014-03-03 01:23:31 --> Config Class Initialized
DEBUG - 2014-03-03 01:23:31 --> Hooks Class Initialized
DEBUG - 2014-03-03 01:24:50 --> Config Class Initialized
DEBUG - 2014-03-03 01:24:50 --> Hooks Class Initialized
DEBUG - 2014-03-03 01:24:50 --> Utf8 Class Initialized
DEBUG - 2014-03-03 01:24:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-03 01:24:50 --> URI Class Initialized
DEBUG - 2014-03-03 01:24:51 --> Router Class Initialized
DEBUG - 2014-03-03 01:24:51 --> No URI present. Default controller set.
DEBUG - 2014-03-03 01:24:51 --> Output Class Initialized
DEBUG - 2014-03-03 01:24:51 --> Security Class Initialized
DEBUG - 2014-03-03 01:24:51 --> Input Class Initialized
DEBUG - 2014-03-03 01:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-03 01:24:51 --> Language Class Initialized
DEBUG - 2014-03-03 01:24:51 --> Loader Class Initialized
DEBUG - 2014-03-03 01:24:51 --> Database Driver Class Initialized
ERROR - 2014-03-03 01:24:51 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\apps\career\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-03-03 01:24:52 --> Session Class Initialized
DEBUG - 2014-03-03 01:24:52 --> Helper loaded: string_helper
DEBUG - 2014-03-03 01:24:52 --> Session routines successfully run
DEBUG - 2014-03-03 01:24:52 --> XML-RPC Class Initialized
DEBUG - 2014-03-03 01:24:52 --> User Agent Class Initialized
DEBUG - 2014-03-03 01:24:52 --> Controller Class Initialized
DEBUG - 2014-03-03 01:24:52 --> Helper loaded: url_helper
DEBUG - 2014-03-03 01:24:52 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-03-03 01:24:52 --> this->setMessage()
DEBUG - 2014-03-03 01:24:52 --> Model Class Initialized
DEBUG - 2014-03-03 01:24:52 --> this->setMessage()
DEBUG - 2014-03-03 01:24:52 --> File loaded: application/views/login.php
DEBUG - 2014-03-03 01:24:58 --> Config Class Initialized
DEBUG - 2014-03-03 01:24:58 --> Hooks Class Initialized
DEBUG - 2014-03-03 01:24:58 --> Utf8 Class Initialized
DEBUG - 2014-03-03 01:24:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-03 01:24:58 --> URI Class Initialized
DEBUG - 2014-03-03 01:24:58 --> Router Class Initialized
DEBUG - 2014-03-03 01:24:58 --> No URI present. Default controller set.
DEBUG - 2014-03-03 01:24:58 --> Output Class Initialized
DEBUG - 2014-03-03 01:24:58 --> Security Class Initialized
DEBUG - 2014-03-03 01:24:58 --> Input Class Initialized
DEBUG - 2014-03-03 01:24:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-03 01:24:58 --> Language Class Initialized
DEBUG - 2014-03-03 01:24:58 --> Loader Class Initialized
DEBUG - 2014-03-03 01:24:58 --> Database Driver Class Initialized
DEBUG - 2014-03-03 01:24:58 --> Session Class Initialized
DEBUG - 2014-03-03 01:24:58 --> Helper loaded: string_helper
DEBUG - 2014-03-03 01:24:58 --> Session routines successfully run
DEBUG - 2014-03-03 01:24:58 --> XML-RPC Class Initialized
DEBUG - 2014-03-03 01:24:58 --> User Agent Class Initialized
DEBUG - 2014-03-03 01:24:58 --> Controller Class Initialized
DEBUG - 2014-03-03 01:24:58 --> Helper loaded: url_helper
DEBUG - 2014-03-03 01:24:58 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-03-03 01:24:58 --> this->setMessage()
DEBUG - 2014-03-03 01:24:58 --> Model Class Initialized
DEBUG - 2014-03-03 01:24:58 --> this->setMessage()
DEBUG - 2014-03-03 01:24:58 --> File loaded: application/views/login.php
DEBUG - 2014-03-03 01:25:32 --> Config Class Initialized
DEBUG - 2014-03-03 01:25:32 --> Hooks Class Initialized
DEBUG - 2014-03-03 01:25:32 --> Utf8 Class Initialized
DEBUG - 2014-03-03 01:25:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-03 01:25:32 --> URI Class Initialized
DEBUG - 2014-03-03 01:25:32 --> Router Class Initialized
DEBUG - 2014-03-03 01:25:32 --> No URI present. Default controller set.
DEBUG - 2014-03-03 01:25:32 --> Output Class Initialized
DEBUG - 2014-03-03 01:25:32 --> Security Class Initialized
DEBUG - 2014-03-03 01:25:32 --> Input Class Initialized
DEBUG - 2014-03-03 01:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-03 01:25:32 --> Language Class Initialized
DEBUG - 2014-03-03 01:25:32 --> Loader Class Initialized
DEBUG - 2014-03-03 01:25:32 --> Database Driver Class Initialized
ERROR - 2014-03-03 01:25:32 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\apps\career\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-03-03 01:25:33 --> Session Class Initialized
DEBUG - 2014-03-03 01:25:33 --> Helper loaded: string_helper
DEBUG - 2014-03-03 01:25:33 --> Session routines successfully run
DEBUG - 2014-03-03 01:25:33 --> XML-RPC Class Initialized
DEBUG - 2014-03-03 01:25:33 --> User Agent Class Initialized
DEBUG - 2014-03-03 01:25:33 --> Controller Class Initialized
DEBUG - 2014-03-03 01:25:33 --> Helper loaded: url_helper
DEBUG - 2014-03-03 01:25:33 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-03-03 01:25:33 --> this->setMessage()
DEBUG - 2014-03-03 01:25:33 --> Model Class Initialized
DEBUG - 2014-03-03 01:25:33 --> this->setMessage()
DEBUG - 2014-03-03 01:25:33 --> File loaded: application/views/login.php
DEBUG - 2014-03-03 01:25:33 --> Final output sent to browser
DEBUG - 2014-03-03 01:25:33 --> Total execution time: 1.4678
DEBUG - 2014-03-03 01:25:39 --> Config Class Initialized
DEBUG - 2014-03-03 01:25:39 --> Hooks Class Initialized
DEBUG - 2014-03-03 01:25:39 --> Utf8 Class Initialized
DEBUG - 2014-03-03 01:25:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-03 01:25:39 --> URI Class Initialized
DEBUG - 2014-03-03 01:25:39 --> Router Class Initialized
DEBUG - 2014-03-03 01:25:39 --> Output Class Initialized
DEBUG - 2014-03-03 01:25:39 --> Security Class Initialized
DEBUG - 2014-03-03 01:25:39 --> Input Class Initialized
DEBUG - 2014-03-03 01:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-03 01:25:39 --> Language Class Initialized
DEBUG - 2014-03-03 01:25:39 --> Loader Class Initialized
DEBUG - 2014-03-03 01:25:39 --> Database Driver Class Initialized
ERROR - 2014-03-03 01:25:39 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\apps\career\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-03-03 01:25:40 --> Session Class Initialized
DEBUG - 2014-03-03 01:25:40 --> Helper loaded: string_helper
DEBUG - 2014-03-03 01:25:40 --> Session routines successfully run
DEBUG - 2014-03-03 01:25:40 --> XML-RPC Class Initialized
DEBUG - 2014-03-03 01:25:40 --> User Agent Class Initialized
DEBUG - 2014-03-03 01:25:40 --> Controller Class Initialized
DEBUG - 2014-03-03 01:25:40 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-03-03 01:25:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-03-03 01:27:34 --> Config Class Initialized
DEBUG - 2014-03-03 01:27:34 --> Hooks Class Initialized
DEBUG - 2014-03-03 01:27:34 --> Utf8 Class Initialized
DEBUG - 2014-03-03 01:27:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-03 01:27:34 --> URI Class Initialized
DEBUG - 2014-03-03 01:27:34 --> Router Class Initialized
DEBUG - 2014-03-03 01:27:34 --> Output Class Initialized
DEBUG - 2014-03-03 01:27:34 --> Security Class Initialized
DEBUG - 2014-03-03 01:27:34 --> Input Class Initialized
DEBUG - 2014-03-03 01:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-03 01:27:34 --> Language Class Initialized
DEBUG - 2014-03-03 01:27:34 --> Loader Class Initialized
DEBUG - 2014-03-03 01:27:34 --> Database Driver Class Initialized
DEBUG - 2014-03-03 01:27:34 --> Session Class Initialized
DEBUG - 2014-03-03 01:27:34 --> Helper loaded: string_helper
DEBUG - 2014-03-03 01:27:34 --> Session routines successfully run
DEBUG - 2014-03-03 01:27:34 --> XML-RPC Class Initialized
DEBUG - 2014-03-03 01:27:34 --> User Agent Class Initialized
DEBUG - 2014-03-03 01:27:34 --> Controller Class Initialized
DEBUG - 2014-03-03 01:27:34 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-03-03 03:21:20 --> Config Class Initialized
DEBUG - 2014-03-03 03:21:20 --> Hooks Class Initialized
DEBUG - 2014-03-03 03:21:20 --> Utf8 Class Initialized
DEBUG - 2014-03-03 03:21:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-03 03:21:20 --> URI Class Initialized
DEBUG - 2014-03-03 03:21:20 --> Router Class Initialized
DEBUG - 2014-03-03 03:21:20 --> Output Class Initialized
DEBUG - 2014-03-03 03:21:20 --> Security Class Initialized
DEBUG - 2014-03-03 03:21:20 --> Input Class Initialized
DEBUG - 2014-03-03 03:21:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-03 03:21:20 --> Language Class Initialized
DEBUG - 2014-03-03 03:21:20 --> Loader Class Initialized
DEBUG - 2014-03-03 03:21:20 --> Database Driver Class Initialized
DEBUG - 2014-03-03 03:21:21 --> Session Class Initialized
DEBUG - 2014-03-03 03:21:21 --> Helper loaded: string_helper
DEBUG - 2014-03-03 03:21:21 --> Session routines successfully run
DEBUG - 2014-03-03 03:21:21 --> XML-RPC Class Initialized
DEBUG - 2014-03-03 03:21:21 --> User Agent Class Initialized
DEBUG - 2014-03-03 03:21:21 --> Controller Class Initialized
DEBUG - 2014-03-03 03:21:21 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-03-03 03:28:25 --> Config Class Initialized
DEBUG - 2014-03-03 03:28:25 --> Hooks Class Initialized
DEBUG - 2014-03-03 03:28:25 --> Utf8 Class Initialized
DEBUG - 2014-03-03 03:28:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-03 03:28:25 --> URI Class Initialized
DEBUG - 2014-03-03 03:28:25 --> Router Class Initialized
DEBUG - 2014-03-03 03:28:25 --> Output Class Initialized
DEBUG - 2014-03-03 03:28:25 --> Security Class Initialized
DEBUG - 2014-03-03 03:28:25 --> Input Class Initialized
DEBUG - 2014-03-03 03:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-03 03:28:25 --> Language Class Initialized
DEBUG - 2014-03-03 03:28:25 --> Loader Class Initialized
DEBUG - 2014-03-03 03:28:25 --> Database Driver Class Initialized
DEBUG - 2014-03-03 03:28:25 --> Session Class Initialized
DEBUG - 2014-03-03 03:28:25 --> Helper loaded: string_helper
DEBUG - 2014-03-03 03:28:25 --> Session routines successfully run
DEBUG - 2014-03-03 03:28:26 --> XML-RPC Class Initialized
DEBUG - 2014-03-03 03:28:26 --> User Agent Class Initialized
DEBUG - 2014-03-03 03:28:26 --> Controller Class Initialized
DEBUG - 2014-03-03 03:28:26 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-03-03 03:28:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-03-03 03:28:36 --> Config Class Initialized
DEBUG - 2014-03-03 03:28:36 --> Hooks Class Initialized
DEBUG - 2014-03-03 03:28:36 --> Utf8 Class Initialized
DEBUG - 2014-03-03 03:28:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-03 03:28:36 --> URI Class Initialized
DEBUG - 2014-03-03 03:28:36 --> Router Class Initialized
DEBUG - 2014-03-03 03:28:36 --> No URI present. Default controller set.
DEBUG - 2014-03-03 03:28:36 --> Output Class Initialized
DEBUG - 2014-03-03 03:28:36 --> Security Class Initialized
DEBUG - 2014-03-03 03:28:36 --> Input Class Initialized
DEBUG - 2014-03-03 03:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-03 03:28:36 --> Language Class Initialized
DEBUG - 2014-03-03 03:28:36 --> Loader Class Initialized
DEBUG - 2014-03-03 03:28:37 --> Database Driver Class Initialized
DEBUG - 2014-03-03 03:28:37 --> Session Class Initialized
DEBUG - 2014-03-03 03:28:37 --> Helper loaded: string_helper
DEBUG - 2014-03-03 03:28:37 --> Session routines successfully run
DEBUG - 2014-03-03 03:28:37 --> XML-RPC Class Initialized
DEBUG - 2014-03-03 03:28:37 --> User Agent Class Initialized
DEBUG - 2014-03-03 03:28:37 --> Controller Class Initialized
DEBUG - 2014-03-03 03:28:37 --> Helper loaded: url_helper
DEBUG - 2014-03-03 03:28:37 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-03-03 03:28:37 --> this->setMessage()
DEBUG - 2014-03-03 03:28:37 --> Model Class Initialized
DEBUG - 2014-03-03 03:28:37 --> this->setMessage()
DEBUG - 2014-03-03 03:28:37 --> File loaded: application/views/login.php
DEBUG - 2014-03-03 03:28:37 --> Final output sent to browser
DEBUG - 2014-03-03 03:28:37 --> Total execution time: 0.7364
DEBUG - 2014-03-03 03:28:40 --> Config Class Initialized
DEBUG - 2014-03-03 03:28:40 --> Hooks Class Initialized
DEBUG - 2014-03-03 03:28:40 --> Utf8 Class Initialized
DEBUG - 2014-03-03 03:28:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-03 03:28:40 --> URI Class Initialized
DEBUG - 2014-03-03 03:28:40 --> Router Class Initialized
DEBUG - 2014-03-03 03:28:40 --> No URI present. Default controller set.
DEBUG - 2014-03-03 03:28:40 --> Output Class Initialized
DEBUG - 2014-03-03 03:28:40 --> Security Class Initialized
DEBUG - 2014-03-03 03:28:40 --> Input Class Initialized
DEBUG - 2014-03-03 03:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-03 03:28:40 --> Language Class Initialized
DEBUG - 2014-03-03 03:28:40 --> Loader Class Initialized
DEBUG - 2014-03-03 03:28:40 --> Database Driver Class Initialized
DEBUG - 2014-03-03 03:28:40 --> Session Class Initialized
DEBUG - 2014-03-03 03:28:40 --> Helper loaded: string_helper
DEBUG - 2014-03-03 03:28:40 --> Session routines successfully run
DEBUG - 2014-03-03 03:28:40 --> XML-RPC Class Initialized
DEBUG - 2014-03-03 03:28:40 --> User Agent Class Initialized
DEBUG - 2014-03-03 03:28:40 --> Controller Class Initialized
DEBUG - 2014-03-03 03:28:40 --> Helper loaded: url_helper
DEBUG - 2014-03-03 03:28:40 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-03-03 03:28:40 --> this->setMessage()
DEBUG - 2014-03-03 03:28:40 --> Model Class Initialized
DEBUG - 2014-03-03 03:28:40 --> this->setMessage()
DEBUG - 2014-03-03 03:28:40 --> File loaded: application/views/login.php
DEBUG - 2014-03-03 03:28:40 --> Final output sent to browser
DEBUG - 2014-03-03 03:28:40 --> Total execution time: 0.6826
