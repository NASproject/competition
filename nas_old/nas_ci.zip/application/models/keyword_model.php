<?php
class Keyword_model extends CI_Model {

	public function __construct()
	{
	}
	
	function set_keyword($args)
	{
		$this->db->set($args);
		$this->db->insert('keyword');
	}
	

}
