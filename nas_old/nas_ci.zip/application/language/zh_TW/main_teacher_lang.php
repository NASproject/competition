<?php
$lang["title"] = "人才推薦計畫－實踐大學資管系";
$lang["footer"] = "實踐大學│資訊管理學系";
$lang["contact_address"] = "高雄市內門區大學路200號J-304系辦";
$lang["contact_phone"] = "07-6678888#4261";
// login main form
$lang["lblFunction1"] = "設定教師專長";
$lang["lblFunction2"] = "設定專題學生專長";
$lang["lblFunction3"] = "設定專題學生";
$lang["lblFunction4"] = "查看廠商指定人才";
$lang["lblFunction5"] = "自行推薦人才";
$lang["formName"] = "教師專長技能";
$lang["btnAdd"] = "增加技能";
$lang["btnSave"] = "儲存";
$lang["btnDelete"] = "刪除";
$lang["lblSkill"] = "技能名稱";
?>
