<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-27 02:41:19 --> Config Class Initialized
DEBUG - 2014-02-27 02:41:19 --> Hooks Class Initialized
DEBUG - 2014-02-27 02:41:19 --> Utf8 Class Initialized
DEBUG - 2014-02-27 02:41:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 02:41:19 --> URI Class Initialized
DEBUG - 2014-02-27 02:41:19 --> Router Class Initialized
DEBUG - 2014-02-27 02:41:19 --> No URI present. Default controller set.
DEBUG - 2014-02-27 02:41:19 --> Output Class Initialized
DEBUG - 2014-02-27 02:41:19 --> Security Class Initialized
DEBUG - 2014-02-27 02:41:19 --> Input Class Initialized
DEBUG - 2014-02-27 02:41:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 02:41:19 --> Language Class Initialized
DEBUG - 2014-02-27 02:41:19 --> Loader Class Initialized
DEBUG - 2014-02-27 02:41:20 --> Database Driver Class Initialized
ERROR - 2014-02-27 02:41:20 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\apps\career\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-02-27 02:41:21 --> Session Class Initialized
DEBUG - 2014-02-27 02:41:21 --> Helper loaded: string_helper
DEBUG - 2014-02-27 02:41:21 --> A session cookie was not found.
DEBUG - 2014-02-27 02:41:21 --> Session routines successfully run
DEBUG - 2014-02-27 02:41:21 --> XML-RPC Class Initialized
DEBUG - 2014-02-27 02:41:21 --> User Agent Class Initialized
DEBUG - 2014-02-27 02:41:21 --> Controller Class Initialized
DEBUG - 2014-02-27 02:41:21 --> Helper loaded: url_helper
DEBUG - 2014-02-27 02:41:21 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-27 02:41:21 --> Model Class Initialized
DEBUG - 2014-02-27 02:41:50 --> Config Class Initialized
DEBUG - 2014-02-27 02:41:50 --> Hooks Class Initialized
DEBUG - 2014-02-27 02:41:50 --> Utf8 Class Initialized
DEBUG - 2014-02-27 02:41:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 02:41:50 --> URI Class Initialized
DEBUG - 2014-02-27 02:41:51 --> Router Class Initialized
DEBUG - 2014-02-27 02:41:51 --> No URI present. Default controller set.
DEBUG - 2014-02-27 02:41:51 --> Output Class Initialized
DEBUG - 2014-02-27 02:41:51 --> Security Class Initialized
DEBUG - 2014-02-27 02:41:51 --> Input Class Initialized
DEBUG - 2014-02-27 02:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 02:41:51 --> Language Class Initialized
DEBUG - 2014-02-27 02:41:51 --> Loader Class Initialized
DEBUG - 2014-02-27 02:41:51 --> Database Driver Class Initialized
ERROR - 2014-02-27 02:41:51 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\apps\career\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-02-27 02:41:52 --> Session Class Initialized
DEBUG - 2014-02-27 02:41:52 --> Helper loaded: string_helper
DEBUG - 2014-02-27 02:41:52 --> Session routines successfully run
DEBUG - 2014-02-27 02:41:52 --> XML-RPC Class Initialized
DEBUG - 2014-02-27 02:41:52 --> User Agent Class Initialized
DEBUG - 2014-02-27 02:41:52 --> Controller Class Initialized
DEBUG - 2014-02-27 02:41:52 --> Helper loaded: url_helper
DEBUG - 2014-02-27 02:41:52 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-27 02:41:52 --> Model Class Initialized
DEBUG - 2014-02-27 02:42:06 --> Config Class Initialized
DEBUG - 2014-02-27 02:42:06 --> Hooks Class Initialized
DEBUG - 2014-02-27 02:42:06 --> Utf8 Class Initialized
DEBUG - 2014-02-27 02:42:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 02:42:06 --> URI Class Initialized
DEBUG - 2014-02-27 02:42:06 --> Router Class Initialized
DEBUG - 2014-02-27 02:42:06 --> No URI present. Default controller set.
DEBUG - 2014-02-27 02:42:06 --> Output Class Initialized
DEBUG - 2014-02-27 02:42:06 --> Security Class Initialized
DEBUG - 2014-02-27 02:42:06 --> Input Class Initialized
DEBUG - 2014-02-27 02:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 02:42:06 --> Language Class Initialized
DEBUG - 2014-02-27 02:42:06 --> Loader Class Initialized
DEBUG - 2014-02-27 02:42:06 --> Database Driver Class Initialized
ERROR - 2014-02-27 02:42:07 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\apps\career\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-02-27 02:42:08 --> Session Class Initialized
DEBUG - 2014-02-27 02:42:08 --> Helper loaded: string_helper
DEBUG - 2014-02-27 02:42:08 --> Session routines successfully run
DEBUG - 2014-02-27 02:42:08 --> XML-RPC Class Initialized
DEBUG - 2014-02-27 02:42:08 --> User Agent Class Initialized
DEBUG - 2014-02-27 02:42:08 --> Controller Class Initialized
DEBUG - 2014-02-27 02:42:08 --> Helper loaded: url_helper
DEBUG - 2014-02-27 02:42:08 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-27 02:42:08 --> Model Class Initialized
DEBUG - 2014-02-27 02:42:08 --> File loaded: application/views/login.php
DEBUG - 2014-02-27 02:42:08 --> Final output sent to browser
DEBUG - 2014-02-27 02:42:08 --> Total execution time: 1.5637
DEBUG - 2014-02-27 02:46:12 --> Config Class Initialized
DEBUG - 2014-02-27 02:46:12 --> Hooks Class Initialized
DEBUG - 2014-02-27 02:46:12 --> Utf8 Class Initialized
DEBUG - 2014-02-27 02:46:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 02:46:12 --> URI Class Initialized
DEBUG - 2014-02-27 02:46:12 --> Router Class Initialized
DEBUG - 2014-02-27 02:46:12 --> No URI present. Default controller set.
DEBUG - 2014-02-27 02:46:12 --> Output Class Initialized
DEBUG - 2014-02-27 02:46:12 --> Security Class Initialized
DEBUG - 2014-02-27 02:46:12 --> Input Class Initialized
DEBUG - 2014-02-27 02:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 02:46:12 --> Language Class Initialized
DEBUG - 2014-02-27 02:46:12 --> Loader Class Initialized
DEBUG - 2014-02-27 02:46:12 --> Database Driver Class Initialized
DEBUG - 2014-02-27 02:46:12 --> Session Class Initialized
DEBUG - 2014-02-27 02:46:12 --> Helper loaded: string_helper
DEBUG - 2014-02-27 02:46:12 --> Session routines successfully run
DEBUG - 2014-02-27 02:46:12 --> XML-RPC Class Initialized
DEBUG - 2014-02-27 02:46:12 --> User Agent Class Initialized
DEBUG - 2014-02-27 02:46:12 --> Controller Class Initialized
DEBUG - 2014-02-27 02:46:12 --> Helper loaded: url_helper
DEBUG - 2014-02-27 02:46:12 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-27 02:46:12 --> Model Class Initialized
DEBUG - 2014-02-27 02:46:12 --> File loaded: application/views/login.php
DEBUG - 2014-02-27 02:46:12 --> Final output sent to browser
DEBUG - 2014-02-27 02:46:12 --> Total execution time: 0.5875
