<html>
 <head>
	<script type="text/javascript" src="{baseURL}public/js/jquery/jquery-1.10.2.min.js"></script>	
	<script type="text/javascript" src="{baseURL}public/js/long_polling.js"></script>
 </head>
 <body>
  <div id="php_log">
	<table border="1" id="JSON_table"></table>
  </div>
 </body>
</html>