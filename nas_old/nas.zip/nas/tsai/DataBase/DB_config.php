<?php
    $DB_host = 'localhost';
    $DB_user = 'nas';
    $DB_password = 'nas2012';
    $DB_DB = 'nas';
?>
